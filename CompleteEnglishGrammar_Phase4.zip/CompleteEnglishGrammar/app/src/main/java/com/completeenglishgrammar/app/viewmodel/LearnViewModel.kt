package com.completeenglishgrammar.app.viewmodel

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.completeenglishgrammar.app.data.Block
import com.completeenglishgrammar.app.data.ContentRepository
import com.completeenglishgrammar.app.data.Flashcard
import com.completeenglishgrammar.app.data.LearnRepository
import com.completeenglishgrammar.app.data.LearnState
import com.completeenglishgrammar.app.data.Note
import com.completeenglishgrammar.app.data.Question
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Holds notes, bookmarks, favourites, flashcards and progress. */
class LearnViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = LearnRepository(app.applicationContext)

    val state: StateFlow<LearnState> =
        repo.state.stateIn(viewModelScope, SharingStarted.Eagerly, LearnState())

    private val _builtInCards = MutableStateFlow<List<Flashcard>>(emptyList())

    /** Cards made from lessons, vocabulary and important questions. */
    val builtInCards: StateFlow<List<Flashcard>> = _builtInCards

    private var studyStart = 0L

    init {
        viewModelScope.launch(Dispatchers.Default) {
            try {
                _builtInCards.value = buildCards(
                    ContentRepository.allLessons(app.applicationContext),
                    ContentRepository.vocabulary(app.applicationContext),
                    ContentRepository.questions(app.applicationContext)
                )
            } catch (e: Exception) {
                _builtInCards.value = emptyList()
            }
        }
    }

    private fun buildCards(
        lessons: List<com.completeenglishgrammar.app.data.Lesson>,
        vocab: List<com.completeenglishgrammar.app.data.VocabWord>,
        questions: List<Question>
    ): List<Flashcard> {
        val out = ArrayList<Flashcard>()
        lessons.forEach { lesson ->
            var n = 0
            lesson.sections.forEach { section ->
                section.blocks.forEach { block ->
                    if (block is Block.Fix) {
                        n += 1
                        val back = block.correct + if (block.rule.isNotBlank()) "\n\n" + block.rule else ""
                        out.add(Flashcard("f:${lesson.topicId}:$n", "fixes", "Correct this sentence:\n" + block.wrong, back))
                    }
                }
            }
        }
        vocab.forEach {
            val back = it.meaning + "\n" + it.urdu + "\n\n" + it.example
            out.add(Flashcard("v:${it.id}", "vocab", it.word, back))
        }
        questions.filter { it.important }.forEach {
            val answer = it.options.getOrNull(it.answerIndex).orEmpty()
            val back = answer + if (it.explanation.isNotBlank()) "\n\n" + it.explanation else ""
            out.add(Flashcard("q:${it.id}", "question", it.text, back))
        }
        return out
    }

    // ---- study timer: call begin when a study screen opens and end when it closes ----

    fun beginStudy() {
        studyStart = SystemClock.elapsedRealtime()
    }

    fun endStudy() {
        if (studyStart == 0L) return
        val seconds = ((SystemClock.elapsedRealtime() - studyStart) / 1000).toInt()
        studyStart = 0L
        viewModelScope.launch { repo.recordStudy(seconds) }
    }

    fun saveNote(existingId: String?, topicId: String, title: String, body: String, created: Long) {
        val now = System.currentTimeMillis()
        val id = existingId ?: ("n" + now)
        viewModelScope.launch {
            repo.saveNote(Note(id, topicId, title.trim(), body.trim(), if (created > 0) created else now, now))
        }
    }

    fun deleteNote(id: String) {
        viewModelScope.launch { repo.deleteNote(id) }
    }

    fun toggleBookmark(topicId: String) {
        viewModelScope.launch { repo.toggleBookmark(topicId) }
    }

    fun toggleFavourite(questionId: String) {
        viewModelScope.launch { repo.toggleFavourite(questionId) }
    }

    fun addCard(front: String, back: String) {
        if (front.isBlank() || back.isBlank()) return
        viewModelScope.launch { repo.addCard(front.trim(), back.trim()) }
    }

    fun deleteCard(id: String) {
        viewModelScope.launch { repo.deleteCard(id) }
    }

    fun reviewCard(id: String, remembered: Boolean) {
        viewModelScope.launch { repo.reviewCard(id, remembered) }
    }

    fun recordQuiz(correct: Int, total: Int, seconds: Int) {
        viewModelScope.launch { repo.recordQuiz(correct, total, seconds) }
    }
}
