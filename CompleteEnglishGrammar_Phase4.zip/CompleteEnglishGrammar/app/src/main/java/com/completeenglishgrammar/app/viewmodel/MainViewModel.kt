package com.completeenglishgrammar.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.completeenglishgrammar.app.data.ThemeMode
import com.completeenglishgrammar.app.data.ThemePalette
import com.completeenglishgrammar.app.data.UserPrefsRepository
import com.completeenglishgrammar.app.data.UserSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = UserPrefsRepository(app.applicationContext)

    /** null until the saved settings have been loaded from disk. */
    val settings: StateFlow<UserSettings?> =
        repo.settings.stateIn<UserSettings?>(viewModelScope, SharingStarted.Eagerly, null)

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query

    fun setQuery(value: String) {
        _query.value = value
    }

    fun completeOnboarding(name: String) {
        viewModelScope.launch { repo.completeOnboarding(name.trim().take(MAX_NAME)) }
    }

    fun setUserName(name: String) {
        viewModelScope.launch { repo.setUserName(name.trim().take(MAX_NAME)) }
    }

    fun markGuideSeen() {
        viewModelScope.launch { repo.setGuideSeen() }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { repo.setThemeMode(mode) }
    }

    fun setPalette(palette: ThemePalette) {
        viewModelScope.launch { repo.setPalette(palette) }
    }

    fun setFontScale(scale: Float) {
        viewModelScope.launch { repo.setFontScale(scale) }
    }

    fun setAccessibilityMode(enabled: Boolean) {
        viewModelScope.launch { repo.setAccessibilityMode(enabled) }
    }

    fun setReduceMotion(enabled: Boolean) {
        viewModelScope.launch { repo.setReduceMotion(enabled) }
    }

    fun setDailyGoal(questions: Int) {
        viewModelScope.launch { repo.setDailyGoal(questions) }
    }

    fun recordTopicViewed(topicId: String) {
        if (topicId.isBlank()) return
        viewModelScope.launch { repo.recordTopicViewed(topicId) }
    }

    companion object {
        const val MAX_NAME = 30
    }
}
