package com.completeenglishgrammar.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.completeenglishgrammar.app.data.ThemeMode
import com.completeenglishgrammar.app.data.ThemePalette
import com.completeenglishgrammar.app.data.UserSettings
import com.completeenglishgrammar.app.ui.components.InfoCard
import com.completeenglishgrammar.app.ui.components.SimpleTopBar
import com.completeenglishgrammar.app.ui.theme.colors
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    settings: UserSettings,
    onThemeMode: (ThemeMode) -> Unit,
    onPalette: (ThemePalette) -> Unit,
    onFontScale: (Float) -> Unit,
    onAccessibility: (Boolean) -> Unit,
    onReduceMotion: (Boolean) -> Unit,
    onDailyGoal: (Int) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = { SimpleTopBar(title = "Settings", onBack = onBack) },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            InfoCard(icon = Icons.Filled.Check, title = "Appearance") {
                Text("Theme", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { onThemeMode(mode) },
                            label = {
                                Text(
                                    when (mode) {
                                        ThemeMode.SYSTEM -> "System"
                                        ThemeMode.LIGHT -> "Light"
                                        ThemeMode.DARK -> "Dark"
                                    }
                                )
                            }
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("Colour theme", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    ThemePalette.entries.forEach { p ->
                        PaletteSwatch(
                            palette = p,
                            selected = settings.palette == p,
                            onClick = { onPalette(p) }
                        )
                    }
                }
            }

            InfoCard(icon = Icons.Filled.Check, title = "Text size") {
                var slider by remember(settings.fontScale) { mutableFloatStateOf(settings.fontScale) }
                Text(
                    text = "${(slider * 100).roundToInt()}%",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Slider(
                    value = slider,
                    onValueChange = { slider = it },
                    onValueChangeFinished = { onFontScale(slider) },
                    valueRange = 0.85f..1.4f,
                    steps = 10
                )
                Text(
                    text = "The quick brown fox jumps over the lazy dog.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            InfoCard(icon = Icons.Filled.Check, title = "Accessibility") {
                ToggleRow(
                    title = "High contrast and larger text",
                    subtitle = "Stronger colours and 15% bigger text",
                    checked = settings.accessibilityMode,
                    onChange = onAccessibility
                )
                Spacer(Modifier.height(8.dp))
                ToggleRow(
                    title = "Reduce animations",
                    subtitle = "Turn off splash and welcome animations",
                    checked = settings.reduceMotion,
                    onChange = onReduceMotion
                )
            }

            InfoCard(icon = Icons.Filled.Check, title = "Daily goal") {
                Text(
                    text = "Questions per day",
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5, 10, 20, 30).forEach { goal ->
                        FilterChip(
                            selected = settings.dailyGoalQuestions == goal,
                            onClick = { onDailyGoal(goal) },
                            label = { Text("$goal") }
                        )
                    }
                }
            }

            InfoCard(icon = Icons.Filled.Check, title = "Language") {
                Text("English", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "Urdu explanations are planned for a later update.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun PaletteSwatch(palette: ThemePalette, selected: Boolean, onClick: () -> Unit) {
    val color = palette.colors().primary
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(color)
                .then(
                    if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                    else Modifier
                )
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            if (selected) {
                Icon(Icons.Filled.Check, contentDescription = "${palette.label} selected", tint = Color.White)
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(palette.label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
