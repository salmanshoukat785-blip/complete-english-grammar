package com.completeenglishgrammar.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.completeenglishgrammar.app.data.UserSettings
import com.completeenglishgrammar.app.ui.components.Avatar
import com.completeenglishgrammar.app.ui.components.InfoCard
import com.completeenglishgrammar.app.ui.components.SimpleTopBar
import com.completeenglishgrammar.app.viewmodel.MainViewModel

@Composable
fun ProfileScreen(
    settings: UserSettings,
    onSaveName: (String) -> Unit,
    onBack: () -> Unit
) {
    var editing by remember { mutableStateOf(false) }
    var draft by remember(settings.userName) { mutableStateOf(settings.userName) }
    val canSave = draft.trim().isNotEmpty()

    fun save() {
        if (!canSave) return
        onSaveName(draft.trim())
        editing = false
    }

    Scaffold(
        topBar = { SimpleTopBar(title = "Profile", onBack = onBack) },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Avatar(name = settings.userName, size = 104.dp)
            Spacer(Modifier.height(16.dp))

            if (!editing) {
                Text(
                    text = settings.userName.ifBlank { "Learner" },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                FilledTonalButton(onClick = { editing = true }) {
                    Icon(Icons.Filled.Edit, contentDescription = null)
                    Spacer(Modifier.padding(horizontal = 4.dp))
                    Text("Edit profile")
                }
            } else {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { if (it.length <= MainViewModel.MAX_NAME) draft = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    label = { Text("Your name") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Words,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { save() })
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = {
                        draft = settings.userName
                        editing = false
                    }) { Text("Cancel") }
                    Button(onClick = { save() }, enabled = canSave) { Text("Save") }
                }
            }

            Spacer(Modifier.height(28.dp))
            InfoCard(icon = Icons.Filled.Flag, title = "Daily goal") {
                Text(
                    text = "${settings.dailyGoalQuestions} questions per day",
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Streaks, scores and badges will appear here soon.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
