package com.completeenglishgrammar.app.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.completeenglishgrammar.app.ui.components.InfoCard
import com.completeenglishgrammar.app.ui.components.SimpleTopBar

/** Change this to your own address. Feedback and "report a question" emails go here. */
const val SUPPORT_EMAIL = "your-email@example.com"

fun sendEmail(context: Context, subject: String, body: String) {
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("mailto:")
        putExtra(Intent.EXTRA_EMAIL, arrayOf(SUPPORT_EMAIL))
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, body)
    }
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "No email app found", android.widget.Toast.LENGTH_SHORT).show()
    }
}

private val faqs = listOf(
    "How do I study a topic?" to "Open Learn, pick a topic, read the easy summary or the detailed lesson, then tap Practice at the bottom.",
    "How do flashcards work?" to "Cards you remember come back after longer gaps (1, 2, 4, 8, 16 days). Cards you miss return to box 0. Open More, then Flashcards.",
    "What do the quiz modes mean?" to "Practice shows answers at once. Timed and Exam have a clock; Exam also takes away 0.25 for each wrong answer. Daily and Weekly challenges change on their own.",
    "How are points earned?" to "10 points for each correct quiz answer, 20 bonus for 80% or more in a quiz of 5+ questions, and 2 points for each flashcard you remember.",
    "How do I move my data to a new phone?" to "Open More, then Backup and data. Create a backup file, copy it to the new phone and restore it there.",
    "The AI tutor does not answer." to "It needs internet and a Gemini API key (free from Google AI Studio). Add the key from the settings icon in the AI tutor."
)

@Composable
fun HelpScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val version = remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    var open by remember { mutableStateOf<Int?>(null) }

    Scaffold(
        topBar = { SimpleTopBar(title = "Help and about", onBack = onBack) },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            InfoCard(Icons.Filled.QuestionAnswer, "Help") {
                faqs.forEachIndexed { i, (q, a) ->
                    Text(
                        text = q,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickableFaq { open = if (open == i) null else i }
                            .padding(vertical = 8.dp)
                    )
                    if (open == i) {
                        Text(a, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(bottom = 8.dp))
                    }
                }
            }
            InfoCard(Icons.Filled.Feedback, "Feedback") {
                Text("Found a mistake or have an idea? Tell us.", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { sendEmail(context, "Feedback: Complete English Grammar $version", "") },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Send feedback") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "Learn English grammar with Complete English Grammar: " +
                                    "https://play.google.com/store/apps/details?id=${context.packageName}"
                            )
                        }
                        context.startActivity(Intent.createChooser(send, "Share the app"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    androidx.compose.material3.Icon(Icons.Filled.Share, contentDescription = null)
                    Spacer(Modifier.padding(horizontal = 4.dp))
                    Text("Share the app")
                }
            }
            InfoCard(Icons.Filled.Lock, "Privacy") {
                Text(
                    "Your name, progress, notes and settings are stored only on this phone. " +
                        "We do not collect them. If you use the AI tutor, the text you type is sent to " +
                        "Google Gemini to get an answer, using your own API key.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            InfoCard(Icons.Filled.Info, "About") {
                Text("Complete English Grammar", fontWeight = FontWeight.Bold)
                Text("Version $version", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Grammar lessons, quizzes, flashcards and an AI tutor for English learners.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

private fun Modifier.clickableFaq(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable(onClick = onClick))
