package com.completeenglishgrammar.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import java.time.LocalDate
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.learnDataStore: DataStore<Preferences> by preferencesDataStore(name = "learn")

const val GENERAL_TOPIC = "general"

data class Note(
    val id: String,
    val topicId: String,
    val title: String,
    val body: String,
    val created: Long,
    val updated: Long
)

/** A flashcard. [deck] is one of: fixes, vocab, question, mine. */
data class Flashcard(
    val id: String,
    val deck: String,
    val front: String,
    val back: String
)

/** Spaced repetition state: Leitner [box] (0-5), the day it is [due], and how often it was reviewed. */
data class CardProgress(val box: Int, val due: Long, val reviews: Int)

data class LearnState(
    val notes: List<Note> = emptyList(),
    val bookmarks: Set<String> = emptySet(),
    val favourites: Set<String> = emptySet(),
    val customCards: List<Flashcard> = emptyList(),
    val cardProgress: Map<String, CardProgress> = emptyMap(),
    val activeDays: Set<Long> = emptySet(),
    val studySeconds: Map<Long, Int> = emptyMap(),
    val points: Int = 0,
    val quizzes: Int = 0,
    val bestPercent: Int = 0
)

class LearnRepository(private val context: Context) {

    private val kNotes = stringPreferencesKey("notes")
    private val kBookmarks = stringPreferencesKey("bookmarks")
    private val kFavourites = stringPreferencesKey("favourites")
    private val kCards = stringPreferencesKey("custom_cards")
    private val kProgress = stringPreferencesKey("card_progress")
    private val kActive = stringPreferencesKey("active_days")
    private val kStudy = stringPreferencesKey("study_seconds")
    private val kPoints = intPreferencesKey("points")
    private val kQuizzes = intPreferencesKey("quizzes")
    private val kBest = intPreferencesKey("best_percent")

    val state: Flow<LearnState> = context.learnDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            LearnState(
                notes = parseNotes(p[kNotes]),
                bookmarks = parseStrings(p[kBookmarks]).toSet(),
                favourites = parseStrings(p[kFavourites]).toSet(),
                customCards = parseCards(p[kCards]),
                cardProgress = parseProgress(p[kProgress]),
                activeDays = parseLongs(p[kActive]).toSet(),
                studySeconds = parseStudy(p[kStudy]),
                points = p[kPoints] ?: 0,
                quizzes = p[kQuizzes] ?: 0,
                bestPercent = p[kBest] ?: 0
            )
        }

    // ---------- notes ----------

    suspend fun saveNote(note: Note) = update { p ->
        val list = parseNotes(p[kNotes]).toMutableList()
        val i = list.indexOfFirst { it.id == note.id }
        if (i >= 0) list[i] = note else list.add(0, note)
        p[kNotes] = notesToJson(list)
        markActive(p)
    }

    suspend fun deleteNote(id: String) = update { p ->
        p[kNotes] = notesToJson(parseNotes(p[kNotes]).filter { it.id != id })
    }

    // ---------- bookmarks and favourites ----------

    suspend fun toggleBookmark(topicId: String) = update { p ->
        p[kBookmarks] = toggled(parseStrings(p[kBookmarks]), topicId)
    }

    suspend fun toggleFavourite(questionId: String) = update { p ->
        p[kFavourites] = toggled(parseStrings(p[kFavourites]), questionId)
    }

    private fun toggled(list: List<String>, value: String): String {
        val next = if (value in list) list.filter { it != value } else list + value
        return JSONArray(next).toString()
    }

    // ---------- custom flashcards ----------

    suspend fun addCard(front: String, back: String) = update { p ->
        val id = "c" + System.currentTimeMillis()
        val list = parseCards(p[kCards]) + Flashcard(id, "mine", front, back)
        p[kCards] = cardsToJson(list)
    }

    suspend fun deleteCard(id: String) = update { p ->
        p[kCards] = cardsToJson(parseCards(p[kCards]).filter { it.id != id })
        val obj = parseObject(p[kProgress])
        obj.remove(id)
        p[kProgress] = obj.toString()
    }

    /** Spaced repetition: a remembered card moves up a box and comes back later. */
    suspend fun reviewCard(id: String, remembered: Boolean) = update { p ->
        val obj = parseObject(p[kProgress])
        val old = obj.optJSONArray(id)
        val box = old?.optInt(0, 0) ?: 0
        val reviews = (old?.optInt(2, 0) ?: 0) + 1
        val newBox = if (remembered) minOf(box + 1, MAX_BOX) else 0
        val due = today() + INTERVALS[newBox]
        obj.put(id, JSONArray().put(newBox).put(due).put(reviews))
        p[kProgress] = obj.toString()
        if (remembered) p[kPoints] = (p[kPoints] ?: 0) + 2
        markActive(p)
    }

    // ---------- progress ----------

    suspend fun recordStudy(seconds: Int) {
        if (seconds < MIN_STUDY_SECONDS) return
        update { p ->
            addStudy(p, seconds)
            markActive(p)
        }
    }

    suspend fun recordQuiz(correct: Int, total: Int, seconds: Int) = update { p ->
        val percent = if (total == 0) 0 else correct * 100 / total
        val bonus = if (total >= 5 && percent >= 80) 20 else 0
        p[kPoints] = (p[kPoints] ?: 0) + correct * 10 + bonus
        p[kQuizzes] = (p[kQuizzes] ?: 0) + 1
        if (total >= 5 && percent > (p[kBest] ?: 0)) p[kBest] = percent
        addStudy(p, seconds)
        markActive(p)
    }

    private fun addStudy(p: MutablePreferences, seconds: Int) {
        val obj = parseObject(p[kStudy])
        val key = today().toString()
        obj.put(key, obj.optInt(key, 0) + seconds)
        // Keep about three months of daily totals.
        val cutoff = today() - 90
        val oldKeys = ArrayList<String>()
        val iter = obj.keys()
        while (iter.hasNext()) {
            val k = iter.next()
            if ((k.toLongOrNull() ?: 0L) < cutoff) oldKeys.add(k)
        }
        oldKeys.forEach { obj.remove(it) }
        p[kStudy] = obj.toString()
    }

    private fun markActive(p: MutablePreferences) {
        val days = parseLongs(p[kActive]).toMutableSet()
        days.add(today())
        val kept = days.sorted().takeLast(400)
        p[kActive] = JSONArray(kept).toString()
    }

    private suspend fun update(block: (MutablePreferences) -> Unit) {
        context.learnDataStore.edit { block(it) }
    }

    // ---------- JSON helpers ----------

    private fun parseObject(raw: String?): JSONObject = try {
        if (raw.isNullOrEmpty()) JSONObject() else JSONObject(raw)
    } catch (e: Exception) {
        JSONObject()
    }

    private fun parseStrings(raw: String?): List<String> = try {
        if (raw.isNullOrEmpty()) emptyList() else {
            val a = JSONArray(raw)
            List(a.length()) { a.getString(it) }
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun parseLongs(raw: String?): List<Long> = try {
        if (raw.isNullOrEmpty()) emptyList() else {
            val a = JSONArray(raw)
            List(a.length()) { a.getLong(it) }
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun parseNotes(raw: String?): List<Note> = try {
        if (raw.isNullOrEmpty()) emptyList() else {
            val a = JSONArray(raw)
            List(a.length()) { i ->
                val o = a.getJSONObject(i)
                Note(
                    id = o.getString("id"),
                    topicId = o.optString("topic", GENERAL_TOPIC),
                    title = o.optString("title", ""),
                    body = o.optString("body", ""),
                    created = o.optLong("created", 0L),
                    updated = o.optLong("updated", 0L)
                )
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun notesToJson(list: List<Note>): String {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject()
                    .put("id", it.id)
                    .put("topic", it.topicId)
                    .put("title", it.title)
                    .put("body", it.body)
                    .put("created", it.created)
                    .put("updated", it.updated)
            )
        }
        return a.toString()
    }

    private fun parseCards(raw: String?): List<Flashcard> = try {
        if (raw.isNullOrEmpty()) emptyList() else {
            val a = JSONArray(raw)
            List(a.length()) { i ->
                val o = a.getJSONObject(i)
                Flashcard(o.getString("id"), "mine", o.getString("front"), o.getString("back"))
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun cardsToJson(list: List<Flashcard>): String {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("front", it.front).put("back", it.back)) }
        return a.toString()
    }

    private fun parseProgress(raw: String?): Map<String, CardProgress> {
        val obj = parseObject(raw)
        val map = HashMap<String, CardProgress>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val a = obj.optJSONArray(key) ?: continue
            map[key] = CardProgress(a.optInt(0, 0), a.optLong(1, 0L), a.optInt(2, 0))
        }
        return map
    }

    private fun parseStudy(raw: String?): Map<Long, Int> {
        val obj = parseObject(raw)
        val map = HashMap<Long, Int>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val day = key.toLongOrNull() ?: continue
            map[day] = obj.optInt(key, 0)
        }
        return map
    }

    companion object {
        const val MAX_BOX = 5
        const val MIN_STUDY_SECONDS = 10
        val INTERVALS = intArrayOf(0, 1, 2, 4, 8, 16)

        fun today(): Long = LocalDate.now().toEpochDay()
    }
}

/** Gives the backup code access to the learn store. */
internal fun Context.learnStore(): DataStore<Preferences> = learnDataStore
