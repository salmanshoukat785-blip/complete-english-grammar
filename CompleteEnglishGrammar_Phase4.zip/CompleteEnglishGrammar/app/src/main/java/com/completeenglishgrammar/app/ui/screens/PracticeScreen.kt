package com.completeenglishgrammar.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.completeenglishgrammar.app.data.Difficulty
import com.completeenglishgrammar.app.data.QStat
import com.completeenglishgrammar.app.data.Question
import com.completeenglishgrammar.app.data.Topics
import com.completeenglishgrammar.app.viewmodel.QuizConfig
import com.completeenglishgrammar.app.viewmodel.QuizMode

@Composable
fun PracticeScreen(
    questions: List<Question>,
    stats: Map<String, QStat>,
    loadFailed: Boolean,
    poolSize: (QuizConfig) -> Int,
    onStart: (QuizConfig) -> Boolean,
    onOpenBank: () -> Unit,
    onMessage: (String) -> Unit
) {
    var mode by rememberSaveable { mutableStateOf(QuizMode.PRACTICE) }
    var topicId by rememberSaveable { mutableStateOf<String?>(null) }
    var difficulty by rememberSaveable { mutableStateOf<Difficulty?>(null) }
    var count by rememberSaveable { mutableStateOf(10) }

    val config = QuizConfig(mode, topicId, difficulty, count)
    // `questions` and `stats` are read here so the number updates when they change.
    val available = if (questions.isEmpty()) 0 else poolSize(config)
    val attempted = stats.values.count { it.attempts > 0 }
    val totalAttempts = stats.values.sumOf { it.attempts }
    val totalCorrect = stats.values.sumOf { it.correct }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Practice",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = when {
                        loadFailed -> "The questions could not be loaded."
                        questions.isEmpty() -> "Loading questions..."
                        else -> "${questions.size} questions - $attempted tried" +
                            if (totalAttempts > 0) " - ${totalCorrect * 100 / totalAttempts}% correct" else ""
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            Card(
                onClick = onOpenBank,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Question bank",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            "Search and filter every question",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        item {
            Text(
                text = "Choose a mode",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(QuizMode.entries.toList()) { m ->
            ModeRow(m, selected = m == mode) { mode = m }
        }

        if (mode.usesFilters) {
            item {
                Text(
                    text = "Topic",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = topicId == null,
                            onClick = { topicId = null },
                            label = { Text("All") }
                        )
                    }
                    items(Topics.all) { t ->
                        FilterChip(
                            selected = topicId == t.id,
                            onClick = { topicId = t.id },
                            label = { Text(t.title) }
                        )
                    }
                }
            }
            item {
                Text(
                    text = "Level",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = difficulty == null,
                        onClick = { difficulty = null },
                        label = { Text("All") }
                    )
                    Difficulty.entries.forEach { d ->
                        FilterChip(
                            selected = difficulty == d,
                            onClick = { difficulty = d },
                            label = { Text(d.label) }
                        )
                    }
                }
            }
        }

        if (mode.fixedCount == 0) {
            item {
                Text(
                    text = "Number of questions",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5, 10, 20, 30).forEach { n ->
                        FilterChip(
                            selected = count == n,
                            onClick = { count = n },
                            label = { Text("$n") }
                        )
                    }
                }
            }
        }

        item {
            val wanted = if (mode.fixedCount > 0) mode.fixedCount else count
            val usable = minOf(available, wanted)
            Column {
                Text(
                    text = if (available == 0) emptyMessage(mode, questions.isEmpty())
                    else "$usable questions ready" +
                        (if (available < wanted && mode.fixedCount == 0) " (only $available match)" else ""),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (!onStart(config)) onMessage(emptyMessage(mode, questions.isEmpty()))
                    },
                    enabled = available > 0,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Start ${mode.label}", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun emptyMessage(mode: QuizMode, stillLoading: Boolean): String = when {
    stillLoading -> "Questions are still loading."
    mode == QuizMode.WRONG -> "No wrong answers yet. Take a quiz first."
    mode == QuizMode.UNATTEMPTED -> "You have tried every question here."
    else -> "No questions match these filters."
}

@Composable
private fun ModeRow(mode: QuizMode, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val borderColor =
        if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                if (selected) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surface
            )
            .border(if (selected) 2.dp else 1.dp, borderColor, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Spacer(Modifier.width(6.dp))
        Column {
            Text(
                text = mode.label,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = mode.blurb,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
