package com.completeenglishgrammar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.completeenglishgrammar.app.data.UserSettings
import com.completeenglishgrammar.app.ui.nav.AppNav
import com.completeenglishgrammar.app.ui.theme.GrammarTheme
import com.completeenglishgrammar.app.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings by viewModel.settings.collectAsState()
            // Until the saved settings load, use the defaults so the splash still draws.
            GrammarTheme(settings = settings ?: UserSettings()) {
                AppNav(vm = viewModel, settings = settings)
            }
        }
    }
}
