package com.completeenglishgrammar.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.quizDataStore: DataStore<Preferences> by preferencesDataStore(name = "quiz")

/** How often a question was answered, and whether the latest answer was right. */
data class QStat(val attempts: Int, val correct: Int, val lastCorrect: Boolean)

data class HistoryEntry(
    val time: Long,
    val mode: String,
    val topic: String,
    val total: Int,
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val score: Double,
    val seconds: Int
)

class QuizStatsRepository(private val context: Context) {

    private val statsKey = stringPreferencesKey("question_stats")
    private val historyKey = stringPreferencesKey("quiz_history")

    val stats: Flow<Map<String, QStat>> = context.quizDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { parseStats(it[statsKey]) }

    val history: Flow<List<HistoryEntry>> = context.quizDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { parseHistory(it[historyKey]) }

    suspend fun record(results: List<Pair<String, Boolean>>, entry: HistoryEntry) {
        context.quizDataStore.edit { p ->
            val obj = try {
                JSONObject(p[statsKey] ?: "{}")
            } catch (e: Exception) {
                JSONObject()
            }
            for ((id, ok) in results) {
                val old = obj.optJSONArray(id)
                val attempts = (old?.optInt(0, 0) ?: 0) + 1
                val correct = (old?.optInt(1, 0) ?: 0) + (if (ok) 1 else 0)
                obj.put(id, JSONArray().put(attempts).put(correct).put(if (ok) 1 else 0))
            }
            p[statsKey] = obj.toString()

            val old = try {
                JSONArray(p[historyKey] ?: "[]")
            } catch (e: Exception) {
                JSONArray()
            }
            val next = JSONArray()
            next.put(entryToJson(entry))
            var i = 0
            while (i < old.length() && next.length() < MAX_HISTORY) {
                next.put(old.get(i))
                i++
            }
            p[historyKey] = next.toString()
        }
    }

    private fun entryToJson(e: HistoryEntry): JSONObject = JSONObject()
        .put("time", e.time)
        .put("mode", e.mode)
        .put("topic", e.topic)
        .put("total", e.total)
        .put("correct", e.correct)
        .put("wrong", e.wrong)
        .put("skipped", e.skipped)
        .put("score", e.score)
        .put("seconds", e.seconds)

    private fun parseStats(raw: String?): Map<String, QStat> {
        if (raw.isNullOrEmpty()) return emptyMap()
        return try {
            val obj = JSONObject(raw)
            val map = HashMap<String, QStat>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val a = obj.getJSONArray(key)
                map[key] = QStat(a.getInt(0), a.getInt(1), a.getInt(2) == 1)
            }
            map
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun parseHistory(raw: String?): List<HistoryEntry> {
        if (raw.isNullOrEmpty()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                HistoryEntry(
                    time = o.getLong("time"),
                    mode = o.getString("mode"),
                    topic = o.getString("topic"),
                    total = o.getInt("total"),
                    correct = o.getInt("correct"),
                    wrong = o.getInt("wrong"),
                    skipped = o.getInt("skipped"),
                    score = o.getDouble("score"),
                    seconds = o.getInt("seconds")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    companion object {
        private const val MAX_HISTORY = 50
    }
}

/** Gives the backup code access to the quiz store. */
internal fun Context.quizStore(): DataStore<Preferences> = quizDataStore
