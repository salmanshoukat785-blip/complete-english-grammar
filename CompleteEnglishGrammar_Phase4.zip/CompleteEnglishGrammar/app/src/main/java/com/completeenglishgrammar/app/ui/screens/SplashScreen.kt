package com.completeenglishgrammar.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.completeenglishgrammar.app.ui.components.LogoMark
import com.completeenglishgrammar.app.ui.theme.BrandDeep
import com.completeenglishgrammar.app.ui.theme.BrandIndigo
import com.completeenglishgrammar.app.ui.theme.BrandLight
import com.completeenglishgrammar.app.ui.theme.LocalReduceMotion
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val BrandGradient = Brush.verticalGradient(listOf(BrandDeep, BrandIndigo, BrandLight))

/**
 * Animated splash. Calls [onFinished] once the minimum display time has passed
 * and the saved settings are ready ([ready]).
 */
@Composable
fun SplashScreen(ready: Boolean, onFinished: () -> Unit) {
    val reduce = LocalReduceMotion.current
    val logoScale = remember { Animatable(if (reduce) 1f else 0.6f) }
    val logoAlpha = remember { Animatable(if (reduce) 1f else 0f) }
    val textAlpha = remember { Animatable(if (reduce) 1f else 0f) }
    var minTimeDone by remember { mutableStateOf(false) }
    val currentOnFinished by rememberUpdatedState(onFinished)

    LaunchedEffect(Unit) {
        if (!reduce) {
            launch {
                logoScale.animateTo(
                    1f,
                    spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    )
                )
            }
            launch { logoAlpha.animateTo(1f, tween(700)) }
            launch {
                delay(500)
                textAlpha.animateTo(1f, tween(700))
            }
        }
        delay(if (reduce) 600 else 2200)
        minTimeDone = true
    }

    LaunchedEffect(minTimeDone, ready) {
        if (minTimeDone && ready) currentOnFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandGradient),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            LogoMark(
                size = 120.dp,
                background = SolidColor(Color.White),
                textColor = BrandIndigo,
                modifier = Modifier.graphicsLayer {
                    scaleX = logoScale.value
                    scaleY = logoScale.value
                    alpha = logoAlpha.value
                }
            )
            Spacer(Modifier.height(24.dp))
            Text(
                text = "Complete English Grammar",
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(horizontal = 32.dp)
                    .graphicsLayer { alpha = textAlpha.value }
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Learn. Practise. Master.",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 15.sp,
                modifier = Modifier.graphicsLayer { alpha = textAlpha.value }
            )
        }
        CircularProgressIndicator(
            color = Color.White.copy(alpha = 0.8f),
            strokeWidth = 2.dp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 40.dp)
                .size(24.dp)
        )
    }
}
