package com.completeenglishgrammar.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.completeenglishgrammar.app.data.HistoryEntry
import com.completeenglishgrammar.app.data.LearnRepository
import com.completeenglishgrammar.app.data.LearnState
import com.completeenglishgrammar.app.data.Progress
import com.completeenglishgrammar.app.data.QStat
import com.completeenglishgrammar.app.data.Question
import com.completeenglishgrammar.app.data.Topics
import com.completeenglishgrammar.app.ui.components.InfoCard
import com.completeenglishgrammar.app.ui.components.PdfExport
import com.completeenglishgrammar.app.ui.components.progressSections

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(
    state: LearnState,
    questions: List<Question>,
    stats: Map<String, QStat>,
    history: List<HistoryEntry>,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val today = LearnRepository.today()
    val daily = remember(state.activeDays) { Progress.daily(state.activeDays, today) }
    val weekly = remember(state.activeDays) { Progress.weekly(state.activeDays, today) }
    val monthly = remember(state.activeDays) { Progress.monthly(state.activeDays, today) }
    val perf = remember(questions, stats) { Progress.topicPerformance(questions, stats) }
    val totalAttempts = remember(stats) { stats.values.sumOf { it.attempts } }
    val totalCorrect = remember(stats) { stats.values.sumOf { it.correct } }
    val badges = remember(state, perf, totalAttempts, daily) {
        Progress.badges(state, perf, totalAttempts, daily.longest)
    }
    val totalMinutes = state.studySeconds.values.sum() / 60
    val accuracy = if (totalAttempts == 0) 0 else totalCorrect * 100 / totalAttempts

    fun export() {
        try {
            val topics = perf.map {
                val title = Topics.byId(it.topicId)?.title ?: it.topicId
                title + ": " + (if (it.accuracy < 0) "not tried" else "${it.accuracy}% (${it.attempts} answers)")
            }
            val totals = listOf(
                "Questions answered: $totalAttempts (accuracy $accuracy%)",
                "Quizzes finished: ${state.quizzes}",
                "Study time: $totalMinutes minutes",
                "Badges earned: ${badges.count { it.earned }} of ${badges.size}"
            )
            val line = "Day streak: ${daily.current} (best ${daily.longest}), " +
                "week streak: ${weekly.current}, month streak: ${monthly.current}"
            val file = PdfExport.create(
                context, "my_progress.pdf", "My progress", "Complete English Grammar",
                progressSections(state.points, line, totals, topics, history)
            )
            PdfExport.share(context, file, "Share progress report")
        } catch (e: Exception) {
            Toast.makeText(context, "Could not create the PDF", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("My progress", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = ::export) {
                        Icon(Icons.Filled.PictureAsPdf, contentDescription = "Export progress as PDF")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                InfoCard(Icons.Filled.LocalFireDepartment, "Streaks") {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat("${daily.current}", "days")
                        Stat("${weekly.current}", "weeks")
                        Stat("${monthly.current}", "months")
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Best day streak: ${daily.longest}. A week counts with 3 active days, a month with 10.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            item {
                InfoCard(Icons.Filled.TrendingUp, "Totals") {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat("${state.points}", "points")
                        Stat("$totalAttempts", "answered")
                        Stat("$accuracy%", "accuracy")
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat("${state.quizzes}", "quizzes")
                        Stat("$totalMinutes", "minutes")
                        Stat("${state.cardProgress.size}", "cards seen")
                    }
                }
            }
            item {
                InfoCard(Icons.Filled.Timer, "Study time, last 7 days") {
                    val days = (6 downTo 0).map { today - it }
                    val minutes = days.map { (state.studySeconds[it] ?: 0) / 60 }
                    val max = (minutes.maxOrNull() ?: 0).coerceAtLeast(1)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        minutes.forEach { m ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$m", style = MaterialTheme.typography.labelSmall)
                                Box(
                                    modifier = Modifier
                                        .width(24.dp)
                                        .height((6 + 70 * m / max).dp)
                                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(6.dp))
                                )
                            }
                        }
                    }
                    Text(
                        "Minutes per day (oldest to today)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            item {
                InfoCard(Icons.Filled.TrendingUp, "Topics") {
                    perf.forEach { p ->
                        val title = Topics.byId(p.topicId)?.title ?: p.topicId
                        Column(modifier = Modifier.padding(vertical = 5.dp)) {
                            Row {
                                Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    if (p.accuracy < 0) "not tried" else "${p.accuracy}%",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            LinearProgressIndicator(
                                progress = { if (p.total == 0) 0f else p.attempted / p.total.toFloat() },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                "${p.attempted} of ${p.total} questions tried",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    val tried = perf.filter { it.accuracy >= 0 }
                    if (tried.size >= 2) {
                        val weak = tried.minByOrNull { it.accuracy }
                        val strong = tried.maxByOrNull { it.accuracy }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Strongest: ${Topics.byId(strong?.topicId.orEmpty())?.title}. " +
                                "Needs work: ${Topics.byId(weak?.topicId.orEmpty())?.title}.",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            item {
                InfoCard(Icons.Filled.EmojiEvents, "Badges (${badges.count { it.earned }}/${badges.size})") {
                    badges.forEach { b ->
                        Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (b.earned) "✓" else "○", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    b.title,
                                    fontWeight = if (b.earned) FontWeight.Bold else FontWeight.Normal,
                                    color = if (b.earned) MaterialTheme.colorScheme.onSurface
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    b.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
