package com.completeenglishgrammar.app.ui.components

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** Reads text aloud with the phone's text-to-speech engine. */
class SpeechHelper(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)

    var ready by mutableStateOf(false)
        private set

    var speaking by mutableStateOf(false)
        private set

    override fun onInit(status: Int) {
        val engine = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        engine.language = Locale.US
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                if (utteranceId == LAST_ID) speaking = false
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                speaking = false
            }
        })
        ready = true
    }

    fun speak(text: String) {
        val engine = tts ?: return
        if (!ready || text.isBlank()) return
        engine.stop()
        val chunks = split(text)
        chunks.forEachIndexed { i, chunk ->
            val id = if (i == chunks.lastIndex) LAST_ID else "chunk_$i"
            engine.speak(chunk, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        }
        speaking = true
    }

    fun stop() {
        tts?.stop()
        speaking = false
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        speaking = false
        ready = false
    }

    /** The engine limits how much text it accepts at once, so send it in pieces. */
    private fun split(text: String): List<String> {
        val chunks = ArrayList<String>()
        val current = StringBuilder()
        for (sentence in text.split("\n")) {
            val line = sentence.trim()
            if (line.isEmpty()) continue
            if (current.length + line.length + 1 > MAX_CHUNK && current.isNotEmpty()) {
                chunks.add(current.toString())
                current.clear()
            }
            if (line.length > MAX_CHUNK) {
                line.chunked(MAX_CHUNK).forEach { chunks.add(it) }
            } else {
                current.append(line).append(' ')
            }
        }
        if (current.isNotBlank()) chunks.add(current.toString())
        return chunks
    }

    companion object {
        private const val LAST_ID = "last"
        private const val MAX_CHUNK = 1500
    }
}
