package com.completeenglishgrammar.app.data

import java.time.LocalDate

data class DailyQuestion(
    val wrong: String,
    val correct: String,
    val rule: String
)

data class DailyFact(
    val title: String,
    val text: String
)

object DailyContent {

    val questions: List<DailyQuestion> = listOf(
        DailyQuestion(
            "She asked me that where he was going.",
            "She asked me where he was going.",
            "Do not use \"that\" before a wh-word in indirect speech."
        ),
        DailyQuestion(
            "Honesty was a good policy.",
            "Honesty is a good policy.",
            "A universal truth always stays in the present tense."
        ),
        DailyQuestion(
            "The Lahore is a big city.",
            "Lahore is a big city.",
            "Do not use an article with proper nouns like city names."
        ),
        DailyQuestion(
            "The sky is enough clear.",
            "The sky is clear enough.",
            "\"Enough\" comes after an adjective."
        ),
        DailyQuestion(
            "I could crossed the river.",
            "I could cross the river.",
            "A modal verb is followed by the first form of the verb."
        ),
        DailyQuestion(
            "If he will come, I shall help him.",
            "If he comes, I shall help him.",
            "Use only one future form in a conditional sentence."
        ),
        DailyQuestion(
            "Unless you do not work, you cannot succeed.",
            "Unless you work, you cannot succeed.",
            "\"Unless\" already means \"if not\", so do not add another negative."
        ),
        DailyQuestion(
            "I wish I was rich.",
            "I wish I were rich.",
            "Use \"were\" for an unreal wish."
        ),
        DailyQuestion(
            "The chair leg is broken.",
            "The leg of the chair is broken.",
            "Use \"of\" for things that are not alive."
        ),
        DailyQuestion(
            "This is the book of Qamar.",
            "This is Qamar's book.",
            "Use 's to show possession for people."
        ),
        DailyQuestion(
            "She is suffering from mump.",
            "She is suffering from mumps.",
            "Some disease names, like mumps and measles, always end in s."
        ),
        DailyQuestion(
            "He distributed his wealth between ten people.",
            "He distributed his wealth among ten people.",
            "Use \"between\" for two and \"among\" for more than two."
        ),
        DailyQuestion(
            "None of the two friends is a criminal.",
            "Neither of the two friends is a criminal.",
            "Use \"neither\" for two people and \"none\" for more than two."
        ),
        DailyQuestion(
            "I drink fewer milk than you.",
            "I drink less milk than you.",
            "Use \"less\" for uncountable nouns and \"fewer\" for countable nouns."
        ),
        DailyQuestion(
            "He invited I to tea.",
            "He invited me to tea.",
            "Use the objective case (me, him, us) after a verb."
        ),
        DailyQuestion(
            "Neither the teacher nor the students was there.",
            "Neither the teacher nor the students were there.",
            "With neither ... nor, the verb agrees with the nearer subject."
        ),
        DailyQuestion(
            "She is living here for two days.",
            "She has been living here for two days.",
            "\"For\" and \"since\" with an ongoing action need the present perfect continuous."
        ),
        DailyQuestion(
            "I have received your letter yesterday.",
            "I received your letter yesterday.",
            "Words like \"yesterday\" and \"last\" need the past indefinite tense."
        ),
        DailyQuestion(
            "Why she is weeping?",
            "Why is she weeping?",
            "In a question, the helping verb comes before the subject."
        ),
        DailyQuestion(
            "She is richest.",
            "She is the richest.",
            "Use \"the\" with the superlative degree."
        ),
        DailyQuestion(
            "Mathematics are tough.",
            "Mathematics is tough.",
            "Subjects like mathematics and physics take a singular verb."
        ),
        DailyQuestion(
            "More you get, more you want.",
            "The more you get, the more you want.",
            "Use \"the\" in both parts of a double comparative."
        ),
        DailyQuestion(
            "I made her to stand.",
            "I made her stand.",
            "Do not use \"to\" after \"make\" plus an object."
        ),
        DailyQuestion(
            "The student is giving the test.",
            "The student is taking the test.",
            "We take a test or an examination."
        ),
        DailyQuestion(
            "He knows to read a newspaper.",
            "He knows how to read a newspaper.",
            "Use \"how to\" after know, learn and teach."
        ),
        DailyQuestion(
            "I regard Saleem my brother.",
            "I regard Saleem as my brother.",
            "Use \"as\" after regard."
        )
    )

    val facts: List<DailyFact> = listOf(
        DailyFact(
            "12 tenses",
            "There are 12 tenses: indefinite, continuous, perfect and perfect continuous, " +
                "each in the present, past and future."
        ),
        DailyFact(
            "Present indefinite",
            "Subject + first form of the verb + object. With he, she and it, add s or es " +
                "to the verb."
        ),
        DailyFact(
            "Past indefinite",
            "Subject + second form of the verb + object. For a question or a negative, " +
                "use \"did\" with the first form."
        ),
        DailyFact(
            "Future indefinite",
            "Subject + will or shall + first form of the verb + object."
        ),
        DailyFact(
            "Continuous tenses",
            "Use a helping verb (is, am, are, was, were, will be) with the first form of " +
                "the verb plus ing."
        ),
        DailyFact(
            "Perfect tenses",
            "Use has, have or had with the third form of the verb. Example: She has finished " +
                "her work."
        ),
        DailyFact(
            "Since and for",
            "Use \"since\" for a point in time (since 8 o'clock) and \"for\" for a length of " +
                "time (for two hours)."
        ),
        DailyFact(
            "Parts of speech",
            "English has eight parts of speech: noun, pronoun, verb, adverb, adjective, " +
                "preposition, conjunction and interjection."
        ),
        DailyFact(
            "Modal verbs",
            "Can, could, may, might, will, would, shall, should and must are followed by the " +
                "first form of the verb."
        ),
        DailyFact(
            "Coordinating conjunctions",
            "For, and, nor, but, or, yet and so join words or sentences of equal importance."
        ),
        DailyFact(
            "Interjections",
            "An interjection shows sudden emotion, like Oh!, Ouch!, Wow! and Help!"
        ),
        DailyFact(
            "Less or fewer?",
            "Use \"less\" with uncountable nouns (less milk) and \"fewer\" with countable " +
                "nouns (fewer shirts)."
        ),
        DailyFact(
            "Active to passive",
            "The object of the active sentence becomes the subject of the passive one, and " +
                "the verb becomes a form of \"be\" plus the third form."
        ),
        DailyFact(
            "Reported speech",
            "When the reporting verb is in the past, shift the tense back by one step: " +
                "present simple becomes past simple."
        ),
        DailyFact(
            "Kinds of nouns",
            "Concrete nouns can be touched (table, fan). Abstract nouns cannot (love, hope, " +
                "courage)."
        )
    )

    private fun dayIndex(): Int = LocalDate.now().toEpochDay().toInt()

    fun questionOfTheDay(): DailyQuestion = questions[dayIndex() % questions.size]

    fun factOfTheDay(): DailyFact = facts[(dayIndex() + 3) % facts.size]
}
