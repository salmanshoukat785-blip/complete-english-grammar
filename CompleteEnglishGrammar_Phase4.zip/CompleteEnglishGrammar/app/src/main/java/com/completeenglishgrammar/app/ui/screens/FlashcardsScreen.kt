package com.completeenglishgrammar.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.completeenglishgrammar.app.data.Flashcard
import com.completeenglishgrammar.app.data.LearnRepository
import com.completeenglishgrammar.app.data.LearnState
import com.completeenglishgrammar.app.ui.components.SimpleTopBar

private enum class Deck(val label: String) {
    DUE("Due today"),
    FIXES("Sentence fixes"),
    VOCAB("Vocabulary"),
    QUESTIONS("Key questions"),
    MINE("My cards")
}

@Composable
fun FlashcardsScreen(
    builtIn: List<Flashcard>,
    state: LearnState,
    onReview: (String, Boolean) -> Unit,
    onAdd: (String, String) -> Unit,
    onDelete: (String) -> Unit,
    onBack: () -> Unit
) {
    var deck by rememberSaveable { mutableStateOf(Deck.DUE) }
    var showAdd by remember { mutableStateOf(false) }
    // Cards answered in this visit, so a card does not jump around while you review.
    val doneIds = remember { mutableStateOf(setOf<String>()) }
    var flipped by rememberSaveable { mutableStateOf(false) }

    val today = LearnRepository.today()
    val all = remember(builtIn, state.customCards) { builtIn + state.customCards }
    val inDeck = when (deck) {
        Deck.DUE -> all.filter { c ->
            val p = state.cardProgress[c.id]
            p != null && p.due <= today
        }
        Deck.FIXES -> all.filter { it.deck == "fixes" }
        Deck.VOCAB -> all.filter { it.deck == "vocab" }
        Deck.QUESTIONS -> all.filter { it.deck == "question" }
        Deck.MINE -> state.customCards
    }
    // In the normal decks, cards never seen or due come first, learned-and-waiting cards are skipped.
    val queue = inDeck.filter { c ->
        if (c.id in doneIds.value) return@filter false
        if (deck == Deck.DUE || deck == Deck.MINE) true
        else {
            val p = state.cardProgress[c.id]
            p == null || p.due <= today
        }
    }
    val card = queue.firstOrNull()
    val newCards = all.count { state.cardProgress[it.id] == null }
    val dueCount = all.count { c -> state.cardProgress[c.id]?.let { it.due <= today } == true }

    Scaffold(
        topBar = { SimpleTopBar(title = "Flashcards", onBack = onBack) },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(Deck.entries.toList()) { d ->
                    FilterChip(
                        selected = deck == d,
                        onClick = {
                            deck = d
                            flipped = false
                        },
                        label = { Text(if (d == Deck.DUE) "${d.label} ($dueCount)" else d.label) }
                    )
                }
            }
            Text(
                text = "$newCards new cards - ${queue.size} left in this deck",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (card == null) {
                    Spacer(Modifier.height(24.dp))
                    Text(
                        text = when (deck) {
                            Deck.DUE -> "Nothing is due. Open another deck to learn new cards."
                            Deck.MINE -> "You have no cards of your own yet. Tap Add card."
                            else -> "All done for today. Cards you remember come back later."
                        },
                        style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    val box = state.cardProgress[card.id]?.box ?: 0
                    Text(
                        text = "Box $box of ${LearnRepository.MAX_BOX}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Card(
                        onClick = { flipped = !flipped },
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (flipped) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(20.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (flipped) card.back else card.front,
                                style = if (flipped) MaterialTheme.typography.titleMedium
                                else MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(16.dp))
                            Text(
                                text = if (flipped) "Tap to see the front" else "Tap to see the answer",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (flipped) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedButton(
                                onClick = {
                                    onReview(card.id, false)
                                    doneIds.value = doneIds.value + card.id
                                    flipped = false
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Again") }
                            Button(
                                onClick = {
                                    onReview(card.id, true)
                                    doneIds.value = doneIds.value + card.id
                                    flipped = false
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("I remembered") }
                        }
                    }
                    if (card.deck == "mine") {
                        TextButton(onClick = { onDelete(card.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Delete this card")
                        }
                    }
                }
            }

            OutlinedButton(
                onClick = { showAdd = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Add card")
            }
        }
    }

    if (showAdd) {
        var front by remember { mutableStateOf("") }
        var back by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("New flashcard") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = front,
                        onValueChange = { front = it },
                        label = { Text("Front (question)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = back,
                        onValueChange = { back = it },
                        label = { Text("Back (answer)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 100.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onAdd(front, back)
                        showAdd = false
                        deck = Deck.MINE
                    },
                    enabled = front.isNotBlank() && back.isNotBlank()
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
        )
    }
}
