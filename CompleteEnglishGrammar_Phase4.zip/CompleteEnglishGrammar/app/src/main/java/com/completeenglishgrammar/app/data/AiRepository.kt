package com.completeenglishgrammar.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private val Context.aiDataStore: DataStore<Preferences> by preferencesDataStore(name = "ai")

data class AiSettings(val apiKey: String = "", val model: String = AiRepository.DEFAULT_MODEL)

data class ChatMessage(val fromUser: Boolean, val text: String)

/**
 * Talks to Google Gemini over its REST API. The key is the user's own, saved only on this
 * phone (it is not part of backups).
 */
class AiRepository(private val context: Context) {

    private val kKey = stringPreferencesKey("api_key")
    private val kModel = stringPreferencesKey("model")

    val settings: Flow<AiSettings> = context.aiDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { AiSettings(it[kKey].orEmpty(), it[kModel]?.ifBlank { null } ?: DEFAULT_MODEL) }

    suspend fun save(key: String, model: String) {
        context.aiDataStore.edit {
            it[kKey] = key.trim()
            it[kModel] = model.trim().ifBlank { DEFAULT_MODEL }
        }
    }

    /** Sends the conversation and returns the reply text, or throws an Exception with a readable message. */
    suspend fun ask(settings: AiSettings, history: List<ChatMessage>): String = withContext(Dispatchers.IO) {
        if (settings.apiKey.isBlank()) throw IllegalStateException("Add your Gemini API key first.")
        val contents = JSONArray()
        history.forEach {
            contents.put(
                JSONObject()
                    .put("role", if (it.fromUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
            )
        }
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT)))
            )
            .put("contents", contents)
            .toString()

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${settings.model}:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", settings.apiKey)
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val msg = try {
                    JSONObject(text).getJSONObject("error").getString("message")
                } catch (e: Exception) {
                    "Request failed ($code)"
                }
                throw IllegalStateException(
                    when (code) {
                        400, 403 -> "Gemini rejected the request. Check your API key. ($msg)"
                        404 -> "Model not found. Check the model name in AI settings."
                        429 -> "Too many requests or the free limit is used up. Try again later."
                        else -> msg
                    }
                )
            }
            val parts = JSONObject(text)
                .getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            sb.toString().trim().ifEmpty { throw IllegalStateException("The AI sent an empty answer. Try rephrasing.") }
        } catch (e: IOException) {
            throw IllegalStateException("No internet connection or the server did not answer.")
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash"

        private const val SYSTEM_PROMPT =
            "You are a friendly English grammar tutor inside the app Complete English Grammar. " +
                "The learner is an Urdu speaker preparing for exams. Explain clearly and briefly, " +
                "with short examples. If the learner writes in Roman Urdu, answer mainly in simple " +
                "English and add a short Roman Urdu hint. When correcting a sentence, show the " +
                "corrected sentence first, then the rule. Only answer English language questions; " +
                "politely decline anything else."
    }
}
