package com.completeenglishgrammar.app.ui.components

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/** One block of a PDF: an optional heading followed by lines of text. */
class PdfSection(val heading: String?, val lines: List<String>)

/** Makes simple text PDFs with the built-in PdfDocument, and shares or prints them. */
object PdfExport {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 44

    fun create(
        context: Context,
        fileName: String,
        title: String,
        subtitle: String?,
        sections: List<PdfSection>
    ): File {
        val titlePaint = paint(20f, bold = true, color = Color.rgb(40, 53, 147))
        val subPaint = paint(11f, bold = false, color = Color.DKGRAY)
        val headingPaint = paint(14f, bold = true, color = Color.rgb(40, 53, 147))
        val bodyPaint = paint(11f, bold = false, color = Color.BLACK)
        val width = PAGE_WIDTH - 2 * MARGIN

        val doc = PdfDocument()
        var pageNumber = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
        var canvas = page.canvas
        var y = MARGIN

        fun draw(text: String, p: TextPaint, gapAfter: Int) {
            if (text.isEmpty()) return
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, p, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(2f, 1f)
                .build()
            if (y + layout.height > PAGE_HEIGHT - MARGIN) {
                doc.finishPage(page)
                pageNumber += 1
                page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
                canvas = page.canvas
                y = MARGIN
            }
            canvas.save()
            canvas.translate(MARGIN.toFloat(), y.toFloat())
            layout.draw(canvas)
            canvas.restore()
            y += layout.height + gapAfter
        }

        draw(title, titlePaint, 4)
        if (!subtitle.isNullOrBlank()) draw(subtitle, subPaint, 14)
        for (section in sections) {
            if (!section.heading.isNullOrBlank()) draw(section.heading, headingPaint, 6)
            for (line in section.lines) draw(line, bodyPaint, 5)
            y += 8
        }
        doc.finishPage(page)

        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, fileName)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    private fun paint(size: Float, bold: Boolean, color: Int): TextPaint {
        return TextPaint().apply {
            isAntiAlias = true
            textSize = size
            this.color = color
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    fun share(context: Context, file: File, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, chooserTitle))
    }

    fun print(context: Context, file: File, jobName: String) {
        val manager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        manager.print(jobName, FilePrintAdapter(file, jobName), null)
    }

    private class FilePrintAdapter(private val file: File, private val name: String) : PrintDocumentAdapter() {

        override fun onLayout(
            oldAttributes: PrintAttributes?,
            newAttributes: PrintAttributes?,
            cancellationSignal: CancellationSignal?,
            callback: LayoutResultCallback?,
            extras: Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) {
                callback?.onLayoutCancelled()
                return
            }
            val info = PrintDocumentInfo.Builder(name)
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                .build()
            callback?.onLayoutFinished(info, true)
        }

        override fun onWrite(
            pages: Array<out PageRange>?,
            destination: ParcelFileDescriptor?,
            cancellationSignal: CancellationSignal?,
            callback: WriteResultCallback?
        ) {
            try {
                val out = destination ?: throw IllegalStateException("No destination")
                FileInputStream(file).use { input ->
                    FileOutputStream(out.fileDescriptor).use { output -> input.copyTo(output) }
                }
                callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback?.onWriteFailed(e.message)
            }
        }
    }
}
