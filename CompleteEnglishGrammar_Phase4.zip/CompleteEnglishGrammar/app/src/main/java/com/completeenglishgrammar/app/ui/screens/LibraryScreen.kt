package com.completeenglishgrammar.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import com.completeenglishgrammar.app.data.GENERAL_TOPIC
import com.completeenglishgrammar.app.data.LearnState
import com.completeenglishgrammar.app.data.Note
import com.completeenglishgrammar.app.data.QStat
import com.completeenglishgrammar.app.data.Question
import com.completeenglishgrammar.app.data.Topics
import com.completeenglishgrammar.app.ui.components.PdfExport
import com.completeenglishgrammar.app.ui.components.notesSections
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    state: LearnState,
    questions: List<Question>,
    stats: Map<String, QStat>,
    onSaveNote: (existingId: String?, topicId: String, title: String, body: String, created: Long) -> Unit,
    onDeleteNote: (String) -> Unit,
    onToggleBookmark: (String) -> Unit,
    onToggleFavourite: (String) -> Unit,
    onOpenTopic: (String) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(0) }
    var editing by remember { mutableStateOf<Note?>(null) }
    var creating by remember { mutableStateOf(false) }
    val expanded = remember { mutableStateMapOf<String, Boolean>() }
    val titles = listOf("Notes", "Bookmarks", "Favourites")

    fun exportNotes() {
        if (state.notes.isEmpty()) {
            Toast.makeText(context, "No notes to export", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val file = PdfExport.create(
                context, "my_notes.pdf", "My notes", "Complete English Grammar",
                notesSections(state.notes)
            )
            PdfExport.share(context, file, "Share notes")
        } catch (e: Exception) {
            Toast.makeText(context, "Could not create the PDF", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Notes and saved", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (tab == 0) {
                        IconButton(onClick = ::exportNotes) {
                            Icon(Icons.Filled.PictureAsPdf, contentDescription = "Export notes as PDF")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            if (tab == 0) {
                ExtendedFloatingActionButton(
                    onClick = { creating = true },
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text("New note") }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            SecondaryTabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                titles.forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
                }
            }
            when (tab) {
                0 -> NotesList(state.notes, onOpen = { editing = it }, onDelete = onDeleteNote)
                1 -> {
                    val marked = Topics.all.filter { it.id in state.bookmarks }
                    if (marked.isEmpty()) {
                        EmptyHint("No bookmarks yet. Tap the bookmark icon inside a lesson to save it here.")
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(20.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(marked, key = { it.id }) { t ->
                                Card(
                                    onClick = { onOpenTopic(t.id) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(t.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Spacer(Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(t.title, fontWeight = FontWeight.Bold)
                                            Text(
                                                t.subtitle,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        IconButton(onClick = { onToggleBookmark(t.id) }) {
                                            Icon(Icons.Filled.Delete, contentDescription = "Remove bookmark")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else -> {
                    val favs = questions.filter { it.id in state.favourites }
                    if (favs.isEmpty()) {
                        EmptyHint("No favourite questions yet. Tap the star on a question in the Question bank.")
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(20.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(favs, key = { it.id }) { q ->
                                QuestionCard(
                                    question = q,
                                    stat = stats[q.id],
                                    open = expanded[q.id] == true,
                                    favourite = true,
                                    onToggle = { expanded[q.id] = !(expanded[q.id] ?: false) },
                                    onFavourite = { onToggleFavourite(q.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (creating || editing != null) {
        NoteDialog(
            note = editing,
            onDismiss = {
                creating = false
                editing = null
            },
            onSave = { topic, title, body ->
                onSaveNote(editing?.id, topic, title, body, editing?.created ?: 0L)
                creating = false
                editing = null
            }
        )
    }
}

@Composable
private fun EmptyHint(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyLarge,
        modifier = Modifier.padding(24.dp)
    )
}

@Composable
private fun NotesList(notes: List<Note>, onOpen: (Note) -> Unit, onDelete: (String) -> Unit) {
    if (notes.isEmpty()) {
        EmptyHint("No notes yet. Tap New note, or write one from inside a lesson.")
        return
    }
    val fmt = remember { DateFormat.getDateInstance(DateFormat.MEDIUM) }
    var toDelete by remember { mutableStateOf<Note?>(null) }
    LazyColumn(
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(notes, key = { it.id }) { n ->
            val topic = if (n.topicId == GENERAL_TOPIC) "General" else (Topics.byId(n.topicId)?.title ?: n.topicId)
            Card(
                onClick = { onOpen(n) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            n.title.ifBlank { "Untitled note" },
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "$topic - ${fmt.format(Date(n.updated))}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            n.body,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = { toDelete = n }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete note")
                    }
                }
            }
        }
    }
    val target = toDelete
    if (target != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete this note?") },
            text = { Text("This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    onDelete(target.id)
                    toDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun NoteDialog(
    note: Note?,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit,
    initialTopic: String = GENERAL_TOPIC
) {
    var title by remember { mutableStateOf(note?.title.orEmpty()) }
    var body by remember { mutableStateOf(note?.body.orEmpty()) }
    var topic by remember { mutableStateOf(note?.topicId ?: initialTopic) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (note == null) "New note" else "Edit note") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = body,
                    onValueChange = { body = it },
                    label = { Text("Note") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp)
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item {
                        FilterChip(
                            selected = topic == GENERAL_TOPIC,
                            onClick = { topic = GENERAL_TOPIC },
                            label = { Text("General") }
                        )
                    }
                    items(Topics.all) { t ->
                        FilterChip(selected = topic == t.id, onClick = { topic = t.id }, label = { Text(t.title) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(topic, title, body) }, enabled = body.isNotBlank()) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
