package com.completeenglishgrammar.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.completeenglishgrammar.app.data.ThemeMode
import com.completeenglishgrammar.app.data.UserSettings

/** True when the user asked for fewer animations. Screens read this before animating. */
val LocalReduceMotion = staticCompositionLocalOf { false }

@Composable
fun GrammarTheme(settings: UserSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val pc = settings.palette.colors()

    var scheme = if (dark) {
        darkColorScheme(
            primary = pc.primaryDark,
            onPrimary = Color(0xFF101114),
            primaryContainer = pc.containerDark,
            onPrimaryContainer = Color.White,
            secondary = pc.secondary,
            onSecondary = Color.Black,
            background = Color(0xFF111318),
            onBackground = Color(0xFFE6E7EC),
            surface = Color(0xFF1A1D24),
            onSurface = Color(0xFFE6E7EC),
            surfaceVariant = Color(0xFF262A33),
            onSurfaceVariant = Color(0xFFC4C7CF),
            outline = Color(0xFF8D919B)
        )
    } else {
        lightColorScheme(
            primary = pc.primary,
            onPrimary = Color.White,
            primaryContainer = pc.containerLight,
            onPrimaryContainer = Color(0xFF14161F),
            secondary = pc.secondary,
            onSecondary = Color.Black,
            background = Color(0xFFF6F7FB),
            onBackground = Color(0xFF14161F),
            surface = Color.White,
            onSurface = Color(0xFF14161F),
            surfaceVariant = Color(0xFFECEEF5),
            onSurfaceVariant = Color(0xFF454956),
            outline = Color(0xFF767A87)
        )
    }

    // Accessibility mode: maximum contrast.
    if (settings.accessibilityMode) {
        scheme = if (dark) {
            scheme.copy(
                background = Color.Black,
                surface = Color.Black,
                onBackground = Color.White,
                onSurface = Color.White,
                onSurfaceVariant = Color.White,
                surfaceVariant = Color(0xFF1C1C1C),
                outline = Color.White
            )
        } else {
            scheme.copy(
                background = Color.White,
                surface = Color.White,
                onBackground = Color.Black,
                onSurface = Color.Black,
                onSurfaceVariant = Color(0xFF111111),
                surfaceVariant = Color(0xFFEDEDED),
                outline = Color.Black
            )
        }
    }

    // Font size: the user's slider, plus 15% extra in accessibility mode.
    val baseDensity = LocalDensity.current
    val userScale = settings.fontScale * (if (settings.accessibilityMode) 1.15f else 1f)

    CompositionLocalProvider(
        LocalDensity provides Density(baseDensity.density, baseDensity.fontScale * userScale),
        LocalReduceMotion provides settings.reduceMotion
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
