package com.completeenglishgrammar.app.ui.components

import com.completeenglishgrammar.app.data.Block
import com.completeenglishgrammar.app.data.HistoryEntry
import com.completeenglishgrammar.app.data.Lesson
import com.completeenglishgrammar.app.data.Note
import com.completeenglishgrammar.app.data.Topics
import com.completeenglishgrammar.app.viewmodel.QuizResult
import java.text.DateFormat
import java.util.Date

/** Turns app content into the sections of a PDF. */

fun lessonSections(lesson: Lesson): List<PdfSection> {
    return lesson.sections.mapIndexed { i, section ->
        val lines = ArrayList<String>()
        section.blocks.forEach { block ->
            when (block) {
                is Block.Text -> lines.add(block.text)
                is Block.Example -> lines.add(
                    "Example: " + block.text + if (block.note.isNotBlank()) " (" + block.note + ")" else ""
                )
                is Block.Important -> lines.add("IMPORTANT: " + block.text)
                is Block.Fix -> lines.add(
                    "Wrong:   " + block.wrong + "\nCorrect: " + block.correct +
                        if (block.rule.isNotBlank()) "\nRule:    " + block.rule else ""
                )
                is Block.Table -> {
                    if (block.header.any { it.isNotBlank() }) lines.add(block.header.joinToString("  |  "))
                    block.rows.forEach { lines.add(it.joinToString("  |  ")) }
                }
            }
        }
        PdfSection("${i + 1}. ${section.title}", lines)
    }
}

fun notesSections(notes: List<Note>): List<PdfSection> {
    val fmt = DateFormat.getDateInstance(DateFormat.MEDIUM)
    return notes.map { n ->
        val topic = if (n.topicId == "general") "General" else (Topics.byId(n.topicId)?.title ?: n.topicId)
        val head = (n.title.ifBlank { "Untitled note" }) + "  (" + topic + ", " + fmt.format(Date(n.updated)) + ")"
        PdfSection(head, listOf(n.body))
    }
}

fun resultSections(result: QuizResult, percent: Int): List<PdfSection> {
    val total = result.session.items.size
    val summary = ArrayList<String>()
    summary.add("Score: ${result.correct} / $total ($percent%)")
    summary.add("Correct: ${result.correct}   Wrong: ${result.wrong}   Skipped: ${result.skipped}")
    if (result.session.mode.negative) summary.add("Marks after negative marking: " + "%.2f".format(result.score))
    summary.add("Time taken: " + "%d:%02d".format(result.seconds / 60, result.seconds % 60))
    val sections = ArrayList<PdfSection>()
    sections.add(PdfSection("Summary", summary))
    result.session.items.forEachIndexed { i, item ->
        val chosen = result.answers.getOrNull(i)
        val lines = ArrayList<String>()
        lines.add("Your answer: " + (if (chosen == null) "skipped" else item.options[chosen]))
        lines.add("Correct answer: " + item.options[item.correctIndex])
        if (item.question.explanation.isNotBlank()) lines.add("Why: " + item.question.explanation)
        sections.add(PdfSection("${i + 1}. ${item.question.text}", lines))
    }
    return sections
}

fun progressSections(
    points: Int,
    streakLine: String,
    totals: List<String>,
    topics: List<String>,
    history: List<HistoryEntry>
): List<PdfSection> {
    val fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
    val sections = ArrayList<PdfSection>()
    sections.add(PdfSection("Overview", listOf("Points: $points", streakLine) + totals))
    sections.add(PdfSection("Topic-wise performance", topics))
    sections.add(
        PdfSection(
            "Recent quizzes",
            history.take(20).map {
                fmt.format(Date(it.time)) + " - " + it.topic + ": " + it.correct + "/" + it.total
            }
        )
    )
    return sections
}
