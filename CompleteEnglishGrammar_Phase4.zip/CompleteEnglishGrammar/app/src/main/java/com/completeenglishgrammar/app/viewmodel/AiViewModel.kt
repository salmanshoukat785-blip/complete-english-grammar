package com.completeenglishgrammar.app.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.completeenglishgrammar.app.data.AiRepository
import com.completeenglishgrammar.app.data.AiSettings
import com.completeenglishgrammar.app.data.ChatMessage
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AiViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AiRepository(app.applicationContext)

    val settings: StateFlow<AiSettings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AiSettings())

    val messages = mutableStateListOf<ChatMessage>()

    var loading by mutableStateOf(false)
        private set

    var error by mutableStateOf<String?>(null)
        private set

    fun saveSettings(key: String, model: String) {
        viewModelScope.launch { repo.save(key, model) }
    }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || loading) return
        error = null
        messages.add(ChatMessage(true, clean))
        loading = true
        // Only the last few turns are sent, to keep requests small.
        val history = messages.toList().takeLast(MAX_TURNS).dropWhile { !it.fromUser }
        viewModelScope.launch {
            try {
                val reply = repo.ask(settings.value, history)
                messages.add(ChatMessage(false, reply))
            } catch (e: Exception) {
                error = e.message ?: "Something went wrong."
            }
            loading = false
        }
    }

    fun clearChat() {
        messages.clear()
        error = null
    }

    companion object {
        const val MAX_TURNS = 12
    }
}
