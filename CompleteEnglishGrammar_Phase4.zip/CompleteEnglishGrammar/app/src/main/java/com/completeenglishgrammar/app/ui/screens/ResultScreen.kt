package com.completeenglishgrammar.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.completeenglishgrammar.app.ui.components.PdfExport
import com.completeenglishgrammar.app.ui.components.resultSections
import com.completeenglishgrammar.app.ui.theme.correctColor
import com.completeenglishgrammar.app.ui.theme.wrongColor
import com.completeenglishgrammar.app.viewmodel.QuizResult
import com.completeenglishgrammar.app.viewmodel.QuizViewModel

@Composable
fun ResultScreen(
    vm: QuizViewModel,
    onDone: () -> Unit,
    onRetryMistakes: () -> Unit
) {
    val result = vm.result ?: return
    val context = LocalContext.current
    val total = result.session.items.size
    val percent = if (total == 0) 0 else result.correct * 100 / total
    val message = when {
        percent >= 80 -> "Excellent work!"
        percent >= 50 -> "Good effort. Keep practising."
        else -> "Keep going. Review your mistakes below."
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Result",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = result.session.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(20.dp))
                Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        progress = { percent / 100f },
                        modifier = Modifier.size(140.dp),
                        strokeWidth = 12.dp,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$percent%",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "${result.correct} / $total",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    text = message,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatBox("Correct", result.correct.toString(), correctColor(), Modifier.weight(1f))
                StatBox("Wrong", result.wrong.toString(), wrongColor(), Modifier.weight(1f))
                StatBox("Skipped", result.skipped.toString(), MaterialTheme.colorScheme.outline, Modifier.weight(1f))
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (result.session.mode.negative) {
                        Text(
                            text = "Score: ${"%.2f".format(result.score)} out of $total",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Each wrong answer costs ${QuizViewModel.NEGATIVE_MARK} marks.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = "Time taken: ${formatTime(result.seconds)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (result.wrong + result.skipped > 0) {
                    Button(
                        onClick = onRetryMistakes,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Practise the mistakes", fontWeight = FontWeight.Bold)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { shareResult(context, result, percent) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Share")
                    }
                    OutlinedButton(
                        onClick = {
                            try {
                                val file = PdfExport.create(
                                    context, "quiz_result.pdf", "Quiz result",
                                    result.session.title, resultSections(result, percent)
                                )
                                PdfExport.share(context, file, "Share result PDF")
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(context, "Could not create the PDF", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("PDF") }
                    OutlinedButton(onClick = onDone, modifier = Modifier.weight(1f)) {
                        Text("Done")
                    }
                }
            }
        }

        item {
            Text(
                text = "Review your answers",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        itemsIndexed(result.session.items) { i, item ->
            val chosen = result.answers.getOrNull(i)
            val right = chosen == item.correctIndex
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "${i + 1}. ${item.question.text}",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = when {
                            chosen == null -> "Your answer: skipped"
                            else -> "Your answer: ${item.options[chosen]}"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (right) correctColor() else wrongColor()
                    )
                    if (!right) {
                        Text(
                            text = "Correct answer: ${item.options[item.correctIndex]}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = correctColor(),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (item.question.explanation.isNotBlank()) {
                        Text(
                            text = item.question.explanation,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatBox(label: String, value: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun shareResult(context: android.content.Context, result: QuizResult, percent: Int) {
    val text = "I scored ${result.correct}/${result.session.items.size} ($percent%) in " +
        "${result.session.title} on Complete English Grammar!"
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, "Share result"))
}
