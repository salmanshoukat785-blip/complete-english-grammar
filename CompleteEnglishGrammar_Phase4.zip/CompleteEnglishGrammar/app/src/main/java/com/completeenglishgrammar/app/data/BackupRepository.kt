package com.completeenglishgrammar.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

/** Saves and restores everything stored on the phone as one JSON text. */
class BackupRepository(private val context: Context) {

    private val stores: Map<String, DataStore<Preferences>>
        get() = mapOf(
            "settings" to context.settingsStore(),
            "quiz" to context.quizStore(),
            "learn" to context.learnStore()
        )

    suspend fun export(): String {
        val root = JSONObject()
        root.put("app", "CompleteEnglishGrammar")
        root.put("version", 1)
        root.put("created", System.currentTimeMillis())
        val data = JSONObject()
        for ((name, store) in stores) {
            val arr = JSONArray()
            store.data.first().asMap().forEach { (key, value) ->
                val type = when (value) {
                    is Boolean -> "b"
                    is Int -> "i"
                    is Long -> "l"
                    is Float -> "f"
                    is String -> "s"
                    else -> null
                }
                if (type != null) {
                    arr.put(JSONObject().put("k", key.name).put("t", type).put("v", value))
                }
            }
            data.put(name, arr)
        }
        root.put("data", data)
        return root.toString()
    }

    /** Returns false when the text is not a valid backup. Nothing is changed in that case. */
    suspend fun restore(text: String): Boolean {
        val root = try {
            JSONObject(text)
        } catch (e: Exception) {
            return false
        }
        if (root.optString("app") != "CompleteEnglishGrammar") return false
        val data = root.optJSONObject("data") ?: return false
        for ((name, store) in stores) {
            val arr = data.optJSONArray(name) ?: continue
            store.edit { p ->
                p.clear()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val k = o.optString("k")
                    if (k.isEmpty()) continue
                    when (o.optString("t")) {
                        "b" -> p[booleanPreferencesKey(k)] = o.optBoolean("v")
                        "i" -> p[intPreferencesKey(k)] = o.optInt("v")
                        "l" -> p[longPreferencesKey(k)] = o.optLong("v")
                        "f" -> p[floatPreferencesKey(k)] = o.optDouble("v").toFloat()
                        "s" -> p[stringPreferencesKey(k)] = o.optString("v")
                    }
                }
            }
        }
        return true
    }

    /** Deletes quiz results, notes, cards and streaks. Name and look stay. */
    suspend fun resetProgress() {
        context.quizStore().edit { it.clear() }
        context.learnStore().edit { it.clear() }
    }
}
