package com.completeenglishgrammar.app.data

import java.time.LocalDate

data class Badge(val title: String, val description: String, val earned: Boolean)

data class TopicPerf(val topicId: String, val total: Int, val attempted: Int, val correct: Int, val attempts: Int) {
    /** Share of answers that were right, or -1 when the topic has not been tried. */
    val accuracy: Int get() = if (attempts == 0) -1 else correct * 100 / attempts
}

data class StreakInfo(val current: Int, val longest: Int)

/** Streak, performance and badge calculations. They only read saved data. */
object Progress {

    /** A day counts as active if anything was studied. */
    fun daily(active: Set<Long>, today: Long): StreakInfo = streak(active, today)

    /** A week counts when you were active on at least [WEEK_DAYS] of its days. */
    fun weekly(active: Set<Long>, today: Long): StreakInfo {
        val perWeek = active.groupBy { Math.floorDiv(it + 3, 7L) }
        val weeks = perWeek.filter { it.value.size >= WEEK_DAYS }.keys
        return streak(weeks, Math.floorDiv(today + 3, 7L))
    }

    /** A month counts when you were active on at least [MONTH_DAYS] of its days. */
    fun monthly(active: Set<Long>, today: Long): StreakInfo {
        val perMonth = active.groupBy {
            val d = LocalDate.ofEpochDay(it)
            d.year * 12L + (d.monthValue - 1)
        }
        val months = perMonth.filter { it.value.size >= MONTH_DAYS }.keys
        val now = LocalDate.ofEpochDay(today)
        return streak(months, now.year * 12L + (now.monthValue - 1))
    }

    /**
     * Counts the run of consecutive numbers in [qualifying] that reaches [current],
     * or [current] - 1 (so an unfinished day / week / month does not break the streak).
     */
    private fun streak(qualifying: Set<Long>, current: Long): StreakInfo {
        if (qualifying.isEmpty()) return StreakInfo(0, 0)
        val start = when {
            current in qualifying -> current
            (current - 1) in qualifying -> current - 1
            else -> null
        }
        var running = 0
        if (start != null) {
            var d: Long = start
            while (d in qualifying) {
                running += 1
                d -= 1
            }
        }
        val sorted = qualifying.sorted()
        var longest = 1
        var run = 1
        for (i in 1 until sorted.size) {
            if (sorted[i] == sorted[i - 1] + 1) {
                run += 1
                if (run > longest) longest = run
            } else {
                run = 1
            }
        }
        return StreakInfo(running, longest)
    }

    fun topicPerformance(questions: List<Question>, stats: Map<String, QStat>): List<TopicPerf> {
        return Topics.all.map { topic ->
            val qs = questions.filter { it.topicId == topic.id }
            var attempted = 0
            var correct = 0
            var attempts = 0
            qs.forEach { q ->
                val s = stats[q.id]
                if (s != null && s.attempts > 0) {
                    attempted += 1
                    correct += s.correct
                    attempts += s.attempts
                }
            }
            TopicPerf(topic.id, qs.size, attempted, correct, attempts)
        }
    }

    fun badges(
        state: LearnState,
        perf: List<TopicPerf>,
        totalAttempts: Int,
        longestDaily: Int
    ): List<Badge> {
        val studyMinutes = state.studySeconds.values.sum() / 60
        val boxed = state.cardProgress.values.count { it.box >= 3 }
        val masteredTopic = perf.any { it.attempts >= 10 && it.accuracy >= 90 }
        return listOf(
            Badge("First Steps", "Finish your first quiz", state.quizzes >= 1),
            Badge("Quiz Regular", "Finish 10 quizzes", state.quizzes >= 10),
            Badge("Century", "Answer 100 questions", totalAttempts >= 100),
            Badge("Sharp Shooter", "Score 90% or more in a quiz of 5+ questions", state.bestPercent >= 90),
            Badge("Perfect Score", "Score 100% in a quiz of 5+ questions", state.bestPercent >= 100),
            Badge("On Fire", "Study 3 days in a row", longestDaily >= 3),
            Badge("Week Warrior", "Study 7 days in a row", longestDaily >= 7),
            Badge("Bookworm", "Study for 60 minutes in total", studyMinutes >= 60),
            Badge("Note Taker", "Write 5 notes", state.notes.size >= 5),
            Badge("Memory Pro", "Move 10 flashcards up to box 3", boxed >= 10),
            Badge("Topic Master", "Answer 10+ questions of one topic with 90% accuracy", masteredTopic)
        )
    }

    private const val WEEK_DAYS = 3
    private const val MONTH_DAYS = 10
}
