package com.completeenglishgrammar.app.viewmodel

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.completeenglishgrammar.app.data.ContentRepository
import com.completeenglishgrammar.app.data.Difficulty
import com.completeenglishgrammar.app.data.HistoryEntry
import com.completeenglishgrammar.app.data.QStat
import com.completeenglishgrammar.app.data.Question
import com.completeenglishgrammar.app.data.QuizStatsRepository
import com.completeenglishgrammar.app.data.Topics
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.IsoFields
import kotlin.random.Random
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class QuizMode(
    val label: String,
    val blurb: String,
    val instant: Boolean,
    val allowBack: Boolean,
    val negative: Boolean,
    val secondsPerQuestion: Int,
    val fixedSeconds: Int,
    val fixedCount: Int,
    val usesFilters: Boolean
) {
    PRACTICE("Practice", "Instant answers and explanations", true, true, false, 0, 0, 0, true),
    SELF_TEST("Self-test", "Answer everything, check at the end", false, true, false, 0, 0, 0, true),
    TIMED("Timed quiz", "30 seconds for each question", false, true, false, 30, 0, 0, true),
    SPEED("Speed test", "As many as you can in 60 seconds", true, false, false, 0, 60, 40, true),
    EXAM("Exam simulation", "20 questions, 1 minute each, negative marking", false, false, true, 60, 0, 20, true),
    DAILY("Daily challenge", "10 questions that change every day", true, false, false, 0, 0, 10, false),
    WEEKLY("Weekly challenge", "20 questions that change every week", false, true, false, 0, 0, 20, false),
    RANDOM("Random mix", "Random questions from every topic", true, true, false, 0, 0, 0, false),
    WRONG("Wrong answers", "Practise the questions you got wrong", true, true, false, 0, 0, 0, true),
    UNATTEMPTED("Unattempted", "Questions you have not tried yet", true, true, false, 0, 0, 0, true)
}

data class QuizConfig(
    val mode: QuizMode,
    val topicId: String?,
    val difficulty: Difficulty?,
    val count: Int
)

data class QuizItem(
    val question: Question,
    val options: List<String>,
    val correctIndex: Int
)

data class QuizSession(
    val mode: QuizMode,
    val title: String,
    val items: List<QuizItem>,
    val totalSeconds: Int,
    val startedAt: Long
)

data class QuizResult(
    val session: QuizSession,
    val answers: List<Int?>,
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val score: Double,
    val seconds: Int
)

class QuizViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = QuizStatsRepository(app.applicationContext)
    private val learnRepo = com.completeenglishgrammar.app.data.LearnRepository(app.applicationContext)

    private val _questions = MutableStateFlow<List<Question>>(emptyList())
    val questions: StateFlow<List<Question>> = _questions

    private val _loadFailed = MutableStateFlow(false)
    val loadFailed: StateFlow<Boolean> = _loadFailed

    val stats: StateFlow<Map<String, QStat>> =
        repo.stats.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val history: StateFlow<List<HistoryEntry>> =
        repo.history.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    var session by mutableStateOf<QuizSession?>(null)
        private set

    var index by mutableIntStateOf(0)
        private set

    var result by mutableStateOf<QuizResult?>(null)
        private set

    val answers = mutableStateListOf<Int?>()

    init {
        viewModelScope.launch(Dispatchers.Default) {
            try {
                _questions.value = ContentRepository.questions(app.applicationContext)
            } catch (e: Exception) {
                _loadFailed.value = true
            }
        }
    }

    /** The questions a quiz with this setup could draw from. */
    fun poolFor(config: QuizConfig): List<Question> {
        val all = _questions.value
        val st = stats.value
        val base = when (config.mode) {
            QuizMode.WRONG -> all.filter {
                val s = st[it.id]
                s != null && s.attempts > 0 && !s.lastCorrect
            }
            QuizMode.UNATTEMPTED -> all.filter { (st[it.id]?.attempts ?: 0) == 0 }
            else -> all
        }
        if (!config.mode.usesFilters) return base
        return base
            .filter { config.topicId == null || it.topicId == config.topicId }
            .filter { config.difficulty == null || it.difficulty == config.difficulty }
    }

    /** Returns false when there are no questions for this setup. */
    fun startQuiz(config: QuizConfig): Boolean {
        val mode = config.mode
        val pool = poolFor(config)
        if (pool.isEmpty()) return false

        val random = when (mode) {
            QuizMode.DAILY -> Random(LocalDate.now().toEpochDay())
            QuizMode.WEEKLY -> {
                val d = LocalDate.now()
                Random(d.get(IsoFields.WEEK_BASED_YEAR) * 100L + d.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR))
            }
            else -> Random(System.nanoTime())
        }
        val wanted = if (mode.fixedCount > 0) mode.fixedCount else config.count
        val picked = pool.shuffled(random).take(wanted)
        val items = picked.map { q ->
            val order = q.options.indices.shuffled(random)
            QuizItem(
                question = q,
                options = order.map { q.options[it] },
                correctIndex = order.indexOf(q.answerIndex)
            )
        }
        val total = when {
            mode.fixedSeconds > 0 -> mode.fixedSeconds
            mode.secondsPerQuestion > 0 -> mode.secondsPerQuestion * items.size
            else -> 0
        }
        val topicLabel = config.topicId?.let { Topics.byId(it)?.title } ?: "All topics"
        val title = if (mode.usesFilters) "${mode.label} - $topicLabel" else mode.label
        beginSession(QuizSession(mode, title, items, total, SystemClock.elapsedRealtime()))
        return true
    }

    private fun beginSession(s: QuizSession) {
        session = s
        answers.clear()
        repeat(s.items.size) { answers.add(null) }
        index = 0
        result = null
    }

    fun answer(choice: Int) {
        val s = session ?: return
        if (index !in answers.indices) return
        if (s.mode.instant && answers[index] != null) return
        answers[index] = choice
    }

    fun next() {
        val s = session ?: return
        if (index < s.items.lastIndex) index += 1
    }

    fun previous() {
        if (index > 0) index -= 1
    }

    fun unansweredCount(): Int = answers.count { it == null }

    fun finish() {
        val s = session ?: return
        if (result != null) return

        var correct = 0
        var wrong = 0
        var skipped = 0
        val recorded = ArrayList<Pair<String, Boolean>>()
        s.items.forEachIndexed { i, item ->
            val a = answers.getOrNull(i)
            when {
                a == null -> skipped += 1
                a == item.correctIndex -> {
                    correct += 1
                    recorded.add(item.question.id to true)
                }
                else -> {
                    wrong += 1
                    recorded.add(item.question.id to false)
                }
            }
        }
        val penalty = if (s.mode.negative) NEGATIVE_MARK else 0.0
        val score = correct - penalty * wrong
        var seconds = ((SystemClock.elapsedRealtime() - s.startedAt) / 1000).toInt()
        if (s.totalSeconds > 0) seconds = seconds.coerceAtMost(s.totalSeconds)

        val r = QuizResult(s, answers.toList(), correct, wrong, skipped, score, seconds)
        result = r

        val entry = HistoryEntry(
            time = System.currentTimeMillis(),
            mode = s.mode.label,
            topic = s.title,
            total = s.items.size,
            correct = correct,
            wrong = wrong,
            skipped = skipped,
            score = score,
            seconds = seconds
        )
        viewModelScope.launch {
            repo.record(recorded, entry)
            learnRepo.recordQuiz(correct, s.items.size, seconds)
        }
    }

    /** Starts a practice round with the questions missed or skipped in the last quiz. */
    fun retryMistakes(): Boolean {
        val r = result ?: return false
        val items = r.session.items.filterIndexed { i, item -> r.answers.getOrNull(i) != item.correctIndex }
        if (items.isEmpty()) return false
        beginSession(
            QuizSession(QuizMode.PRACTICE, "Mistakes review", items, 0, SystemClock.elapsedRealtime())
        )
        return true
    }

    fun clear() {
        session = null
        result = null
        answers.clear()
        index = 0
    }

    companion object {
        const val NEGATIVE_MARK = 0.25

        /** Questions answered today, taken from the saved quiz history. */
        fun answeredToday(history: List<HistoryEntry>): Int {
            val today = LocalDate.now()
            return history
                .filter {
                    Instant.ofEpochMilli(it.time).atZone(ZoneId.systemDefault()).toLocalDate() == today
                }
                .sumOf { it.correct + it.wrong }
        }
    }
}
