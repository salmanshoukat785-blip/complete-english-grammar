package com.completeenglishgrammar.app.ui.screens

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.completeenglishgrammar.app.ui.theme.correctColor
import com.completeenglishgrammar.app.ui.theme.wrongColor
import com.completeenglishgrammar.app.viewmodel.QuizViewModel
import kotlinx.coroutines.delay

internal enum class OptionState { NORMAL, SELECTED, CORRECT, WRONG, DIM }

@Composable
fun QuizScreen(vm: QuizViewModel, onExit: () -> Unit, onFinished: () -> Unit) {
    val session = vm.session
    val result = vm.result

    // After finishing, move on to the result screen.
    LaunchedEffect(result) {
        if (result != null) onFinished()
    }
    // Nothing to show (for example after the app was restarted): go back.
    LaunchedEffect(session) {
        if (session == null) onExit()
    }
    if (session == null) return

    var showQuit by remember { mutableStateOf(false) }
    var showFinish by remember { mutableStateOf(false) }
    BackHandler { showQuit = true }

    var remaining by remember(session) { mutableIntStateOf(session.totalSeconds) }
    LaunchedEffect(session) {
        if (session.totalSeconds > 0) {
            while (true) {
                val elapsed = ((SystemClock.elapsedRealtime() - session.startedAt) / 1000).toInt()
                val left = session.totalSeconds - elapsed
                remaining = left.coerceAtLeast(0)
                if (left <= 0) {
                    vm.finish()
                    break
                }
                delay(250)
            }
        }
    }

    val items = session.items
    val index = vm.index.coerceIn(0, items.lastIndex)
    val item = items[index]
    val chosen: Int? = vm.answers.getOrNull(index)
    val mode = session.mode
    val answered = chosen != null
    val isLast = index == items.lastIndex
    val showFeedback = mode.instant && answered

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { showQuit = true }) {
                Icon(Icons.Filled.Close, contentDescription = "Quit quiz")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Question ${index + 1} of ${items.size}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = session.title,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
            if (session.totalSeconds > 0) {
                val low = remaining <= 10
                Text(
                    text = formatTime(remaining),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (low) wrongColor() else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 12.dp)
                )
            }
        }
        LinearProgressIndicator(
            progress = { (index + 1).toFloat() / items.size },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = item.question.type.label + " - " + item.question.difficulty.label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = item.question.text,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(4.dp))
            item.options.forEachIndexed { i, text ->
                val state = when {
                    showFeedback && i == item.correctIndex -> OptionState.CORRECT
                    showFeedback && i == chosen -> OptionState.WRONG
                    showFeedback -> OptionState.DIM
                    chosen == i -> OptionState.SELECTED
                    else -> OptionState.NORMAL
                }
                OptionRow(
                    letter = ('A' + i).toString(),
                    text = text,
                    state = state,
                    enabled = !(mode.instant && answered),
                    onClick = { vm.answer(i) }
                )
            }
            if (showFeedback) {
                val right = chosen == item.correctIndex
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(14.dp)
                ) {
                    Text(
                        text = if (right) "Correct!" else "Not quite",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (right) correctColor() else wrongColor()
                    )
                    if (item.question.explanation.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(item.question.explanation, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (mode.allowBack && index > 0) {
                OutlinedButton(onClick = { vm.previous() }) { Text("Previous") }
            }
            Spacer(Modifier.weight(1f))
            if (!mode.instant && !answered && !isLast) {
                TextButton(onClick = { vm.next() }) { Text("Skip") }
            }
            Button(
                onClick = {
                    if (isLast) {
                        if (vm.unansweredCount() > 0) showFinish = true else vm.finish()
                    } else {
                        vm.next()
                    }
                },
                enabled = !mode.instant || answered
            ) {
                Text(if (isLast) "Finish" else "Next")
            }
        }
    }

    if (showQuit) {
        AlertDialog(
            onDismissRequest = { showQuit = false },
            title = { Text("Quit this quiz?") },
            text = { Text("Your answers in this quiz will not be saved.") },
            confirmButton = {
                TextButton(onClick = {
                    showQuit = false
                    onExit()
                }) { Text("Quit") }
            },
            dismissButton = {
                TextButton(onClick = { showQuit = false }) { Text("Keep going") }
            }
        )
    }

    if (showFinish) {
        AlertDialog(
            onDismissRequest = { showFinish = false },
            title = { Text("Finish the quiz?") },
            text = { Text("${vm.unansweredCount()} question(s) are still unanswered.") },
            confirmButton = {
                TextButton(onClick = {
                    showFinish = false
                    vm.finish()
                }) { Text("Finish") }
            },
            dismissButton = {
                TextButton(onClick = { showFinish = false }) { Text("Go back") }
            }
        )
    }
}

internal fun formatTime(totalSeconds: Int): String {
    val m = totalSeconds / 60
    val s = totalSeconds % 60
    return "%d:%02d".format(m, s)
}

@Composable
internal fun OptionRow(
    letter: String,
    text: String,
    state: OptionState,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    val accent: Color = when (state) {
        OptionState.CORRECT -> correctColor()
        OptionState.WRONG -> wrongColor()
        OptionState.SELECTED -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.outlineVariant
    }
    val fill: Color = when (state) {
        OptionState.CORRECT -> correctColor().copy(alpha = 0.15f)
        OptionState.WRONG -> wrongColor().copy(alpha = 0.15f)
        OptionState.SELECTED -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surface
    }
    val strong = state == OptionState.CORRECT || state == OptionState.WRONG || state == OptionState.SELECTED
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(fill)
            .border(if (strong) 2.dp else 1.dp, accent, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(if (strong) accent else MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            when (state) {
                OptionState.CORRECT -> Icon(
                    Icons.Filled.Check,
                    contentDescription = "Correct answer",
                    modifier = Modifier.size(18.dp),
                    tint = Color.White
                )
                OptionState.WRONG -> Icon(
                    Icons.Filled.Close,
                    contentDescription = "Your wrong answer",
                    modifier = Modifier.size(18.dp),
                    tint = Color.White
                )
                else -> Text(
                    text = letter,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (state == OptionState.SELECTED) Color.White
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            color = if (state == OptionState.DIM) MaterialTheme.colorScheme.onSurfaceVariant
            else MaterialTheme.colorScheme.onSurface
        )
    }
}
