package com.completeenglishgrammar.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Loads lessons and questions from the JSON files in assets/. */
object ContentRepository {

    private var lessonMap: Map<String, Lesson>? = null
    private var questionList: List<Question>? = null

    @Synchronized
    fun lesson(context: Context, topicId: String): Lesson? {
        val map = lessonMap ?: loadLessons(context).also { lessonMap = it }
        return map[topicId]
    }

    @Synchronized
    fun questions(context: Context): List<Question> {
        return questionList ?: loadQuestions(context).also { questionList = it }
    }

    private fun readAsset(context: Context, name: String): String =
        context.assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }

    private fun strings(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return List(arr.length()) { arr.getString(it) }
    }

    private fun loadLessons(context: Context): Map<String, Lesson> {
        val arr = JSONArray(readAsset(context, "lessons.json"))
        val result = LinkedHashMap<String, Lesson>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val sectionsJson = o.getJSONArray("sections")
            val sections = ArrayList<Section>()
            for (j in 0 until sectionsJson.length()) {
                val so = sectionsJson.getJSONObject(j)
                val blocksJson = so.getJSONArray("blocks")
                val blocks = ArrayList<Block>()
                for (k in 0 until blocksJson.length()) {
                    blocks.add(parseBlock(blocksJson.getJSONObject(k)))
                }
                sections.add(Section(so.getString("title"), blocks))
            }
            val id = o.getString("topicId")
            result[id] = Lesson(
                topicId = id,
                easy = strings(o.optJSONArray("easy")),
                sections = sections,
                related = strings(o.optJSONArray("related"))
            )
        }
        return result
    }

    private fun parseBlock(o: JSONObject): Block {
        return when (o.getString("type")) {
            "table" -> {
                val rowsJson = o.getJSONArray("rows")
                Block.Table(
                    header = strings(o.getJSONArray("header")),
                    rows = List(rowsJson.length()) { strings(rowsJson.getJSONArray(it)) }
                )
            }
            "example" -> Block.Example(o.getString("text"), o.optString("note", ""))
            "important" -> Block.Important(o.getString("text"))
            "fix" -> Block.Fix(
                o.getString("wrong"),
                o.getString("correct"),
                o.optString("rule", "")
            )
            else -> Block.Text(o.getString("text"))
        }
    }

    private fun loadQuestions(context: Context): List<Question> {
        val arr = JSONArray(readAsset(context, "questions.json"))
        val list = ArrayList<Question>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                Question(
                    id = o.getString("id"),
                    topicId = o.getString("topic"),
                    difficulty = Difficulty.valueOf(o.getString("level")),
                    type = QuestionType.valueOf(o.getString("type")),
                    text = o.getString("q"),
                    options = strings(o.getJSONArray("options")),
                    answerIndex = o.getInt("answer"),
                    explanation = o.optString("explanation", ""),
                    important = o.optBoolean("important", false)
                )
            )
        }
        return list
    }
}
