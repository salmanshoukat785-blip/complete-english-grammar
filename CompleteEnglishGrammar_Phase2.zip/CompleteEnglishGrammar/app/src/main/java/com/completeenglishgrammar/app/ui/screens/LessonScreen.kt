package com.completeenglishgrammar.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.completeenglishgrammar.app.data.Block
import com.completeenglishgrammar.app.data.ContentRepository
import com.completeenglishgrammar.app.data.Lesson
import com.completeenglishgrammar.app.data.Section
import com.completeenglishgrammar.app.data.Topic
import com.completeenglishgrammar.app.data.Topics
import com.completeenglishgrammar.app.ui.components.InfoCard
import com.completeenglishgrammar.app.ui.components.SpeechHelper
import com.completeenglishgrammar.app.ui.theme.correctColor
import com.completeenglishgrammar.app.ui.theme.wrongColor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val FIRST_SECTION_ITEM = 2

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonScreen(
    topic: Topic?,
    onBack: () -> Unit,
    onOpenTopic: (String) -> Unit,
    onPractice: (String) -> Unit
) {
    val context = LocalContext.current
    val speech = remember { SpeechHelper(context) }
    DisposableEffect(Unit) { onDispose { speech.shutdown() } }

    val loaded by produceState(initialValue = false to (null as Lesson?), key1 = topic?.id) {
        val id = topic?.id
        val lesson = if (id == null) {
            null
        } else {
            withContext(Dispatchers.IO) {
                try {
                    ContentRepository.lesson(context, id)
                } catch (e: Exception) {
                    null
                }
            }
        }
        value = true to lesson
    }
    val lesson = loaded.second

    var detailed by rememberSaveable { mutableStateOf(true) }
    var showToc by remember { mutableStateOf(false) }
    var pendingScroll by remember { mutableStateOf<Int?>(null) }
    val listState = rememberLazyListState()

    LaunchedEffect(pendingScroll, detailed, lesson) {
        val target = pendingScroll
        if (target != null && detailed && lesson != null) {
            listState.scrollToItem(FIRST_SECTION_ITEM + target)
            pendingScroll = null
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(topic?.title ?: "Lesson", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (lesson != null) {
                        IconButton(
                            onClick = {
                                if (speech.speaking) speech.stop()
                                else speech.speak(lessonToSpeech(lesson, detailed))
                            },
                            enabled = speech.ready
                        ) {
                            Icon(
                                imageVector = if (speech.speaking) Icons.Filled.Stop
                                else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = if (speech.speaking) "Stop reading" else "Read aloud"
                            )
                        }
                        IconButton(onClick = { showToc = true }) {
                            Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Table of contents")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        when {
            topic == null -> CenterMessage(padding, "This topic could not be found.")
            !loaded.first -> Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
            lesson == null -> CenterMessage(padding, "The lesson content could not be loaded.")
            else -> LessonBody(
                padding = padding,
                topic = topic,
                lesson = lesson,
                detailed = detailed,
                onDetailed = { detailed = it },
                listState = listState,
                onOpenTopic = onOpenTopic,
                onPractice = onPractice
            )
        }
    }

    if (showToc && lesson != null) {
        AlertDialog(
            onDismissRequest = { showToc = false },
            title = { Text("Table of contents") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    lesson.sections.forEachIndexed { i, section ->
                        Text(
                            text = "${i + 1}. ${section.title}",
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showToc = false
                                    detailed = true
                                    pendingScroll = i
                                }
                                .padding(vertical = 10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showToc = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun CenterMessage(padding: androidx.compose.foundation.layout.PaddingValues, message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding),
        contentAlignment = Alignment.Center
    ) {
        Text(message, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun LessonBody(
    padding: androidx.compose.foundation.layout.PaddingValues,
    topic: Topic,
    lesson: Lesson,
    detailed: Boolean,
    onDetailed: (Boolean) -> Unit,
    listState: androidx.compose.foundation.lazy.LazyListState,
    onOpenTopic: (String) -> Unit,
    onPractice: (String) -> Unit
) {
    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .padding(padding),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // item 0: header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = topic.icon,
                        contentDescription = null,
                        modifier = Modifier.size(36.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = topic.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // item 1: easy / detailed switch
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = !detailed,
                    onClick = { onDetailed(false) },
                    label = { Text("Easy summary") }
                )
                FilterChip(
                    selected = detailed,
                    onClick = { onDetailed(true) },
                    label = { Text("Detailed lesson") }
                )
            }
        }

        if (!detailed) {
            // item 2: easy summary
            item {
                InfoCard(icon = Icons.Filled.Lightbulb, title = "Easy explanation") {
                    SelectionContainer {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            lesson.easy.forEach { point ->
                                Row {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(20.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Text(point, style = MaterialTheme.typography.bodyLarge)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { onDetailed(true) }) { Text("Read the detailed lesson") }
                }
            }
        } else {
            // items 2..: one item per section
            items(lesson.sections.size) { i -> SectionView(i + 1, lesson.sections[i]) }
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { onPractice(topic.id) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Practise this topic", fontWeight = FontWeight.Bold)
                }

                val related = lesson.related.mapNotNull { Topics.byId(it) }
                if (related.isNotEmpty()) {
                    Text(
                        text = "Related topics",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        related.forEach { r ->
                            AssistChip(onClick = { onOpenTopic(r.id) }, label = { Text(r.title) })
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun SectionView(number: Int, section: Section) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
    ) {
        Text(
            text = "$number. ${section.title}",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(10.dp))
        SelectionContainer {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                section.blocks.forEach { BlockView(it) }
            }
        }
    }
}

@Composable
private fun BlockView(block: Block) {
    when (block) {
        is Block.Text -> Text(
            text = block.text,
            style = MaterialTheme.typography.bodyLarge
        )
        is Block.Table -> TableView(block)
        is Block.Example -> ExampleView(block)
        is Block.Important -> ImportantView(block)
        is Block.Fix -> FixView(block)
    }
}

@Composable
private fun TableView(table: Block.Table) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
    ) {
        if (table.header.any { it.isNotBlank() }) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(horizontal = 6.dp, vertical = 8.dp)
            ) {
                table.header.forEach { cell ->
                    Text(
                        text = cell,
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
        table.rows.forEachIndexed { r, row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (r % 2 == 0) MaterialTheme.colorScheme.surface
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .padding(horizontal = 6.dp, vertical = 8.dp)
            ) {
                row.forEachIndexed { c, cell ->
                    Text(
                        text = cell,
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = if (c == 0) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
private fun ExampleView(example: Block.Example) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(12.dp)
    ) {
        Text(
            text = example.text,
            style = MaterialTheme.typography.bodyLarge,
            fontStyle = FontStyle.Italic
        )
        if (example.note.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = example.note,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ImportantView(block: Block.Important) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f))
            .padding(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = Icons.Filled.Lightbulb,
            contentDescription = "Important",
            tint = MaterialTheme.colorScheme.secondary
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text = block.text,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun FixView(fix: Block.Fix) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "Wrong",
                modifier = Modifier.size(20.dp),
                tint = wrongColor()
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = fix.wrong,
                style = MaterialTheme.typography.bodyLarge,
                color = wrongColor(),
                textDecoration = TextDecoration.LineThrough
            )
        }
        Row(verticalAlignment = Alignment.Top) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = "Correct",
                modifier = Modifier.size(20.dp),
                tint = correctColor()
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = fix.correct,
                style = MaterialTheme.typography.bodyLarge,
                color = correctColor(),
                fontWeight = FontWeight.SemiBold
            )
        }
        if (fix.rule.isNotBlank()) {
            Text(
                text = fix.rule,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun lessonToSpeech(lesson: Lesson, detailed: Boolean): String {
    val sb = StringBuilder()
    if (!detailed) {
        lesson.easy.forEach { sb.append(it).append('\n') }
        return sb.toString()
    }
    lesson.sections.forEach { section ->
        sb.append(section.title).append(".\n")
        section.blocks.forEach { block ->
            when (block) {
                is Block.Text -> sb.append(block.text).append('\n')
                is Block.Example -> sb.append(block.text).append('\n')
                is Block.Important -> sb.append("Important. ").append(block.text).append('\n')
                is Block.Fix -> sb.append("Wrong: ").append(block.wrong)
                    .append(". Correct: ").append(block.correct).append(". ")
                    .append(block.rule).append('\n')
                is Block.Table -> block.rows.forEach { row ->
                    sb.append(row.joinToString(", ")).append(".\n")
                }
            }
        }
    }
    return sb.toString()
}
