package com.completeenglishgrammar.app.data

enum class Difficulty(val label: String) {
    EASY("Easy"),
    MEDIUM("Medium"),
    HARD("Hard")
}

enum class QuestionType(val label: String) {
    MCQ("MCQ"),
    FILL("Fill in the blank"),
    CORRECT("Sentence correction"),
    ERROR("Error spotting")
}

data class Question(
    val id: String,
    val topicId: String,
    val difficulty: Difficulty,
    val type: QuestionType,
    val text: String,
    val options: List<String>,
    val answerIndex: Int,
    val explanation: String,
    val important: Boolean
)

/** One piece of lesson content. */
sealed interface Block {
    data class Text(val text: String) : Block
    data class Table(val header: List<String>, val rows: List<List<String>>) : Block
    data class Example(val text: String, val note: String) : Block
    data class Important(val text: String) : Block
    data class Fix(val wrong: String, val correct: String, val rule: String) : Block
}

data class Section(val title: String, val blocks: List<Block>)

data class Lesson(
    val topicId: String,
    val easy: List<String>,
    val sections: List<Section>,
    val related: List<String>
)
