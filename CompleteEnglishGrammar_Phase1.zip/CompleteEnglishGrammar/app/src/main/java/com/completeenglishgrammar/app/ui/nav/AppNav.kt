package com.completeenglishgrammar.app.ui.nav

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.completeenglishgrammar.app.data.Topics
import com.completeenglishgrammar.app.data.UserSettings
import com.completeenglishgrammar.app.ui.screens.HomeScreen
import com.completeenglishgrammar.app.ui.screens.LearnScreen
import com.completeenglishgrammar.app.ui.screens.MoreScreen
import com.completeenglishgrammar.app.ui.screens.NameScreen
import com.completeenglishgrammar.app.ui.screens.OnboardingScreen
import com.completeenglishgrammar.app.ui.screens.PracticeScreen
import com.completeenglishgrammar.app.ui.screens.ProfileScreen
import com.completeenglishgrammar.app.ui.screens.SettingsScreen
import com.completeenglishgrammar.app.ui.screens.SplashScreen
import com.completeenglishgrammar.app.ui.screens.TopicScreen
import com.completeenglishgrammar.app.ui.screens.WelcomeScreen
import com.completeenglishgrammar.app.viewmodel.MainViewModel
import kotlinx.coroutines.launch

object Routes {
    const val SPLASH = "splash"
    const val WELCOME = "welcome"
    const val ONBOARDING = "onboarding"
    const val NAME = "name"
    const val HOME = "home"
    const val LEARN = "learn"
    const val PRACTICE = "practice"
    const val MORE = "more"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val TOPIC = "topic"
}

private data class BottomItem(val route: String, val label: String, val icon: ImageVector)

private val bottomItems = listOf(
    BottomItem(Routes.HOME, "Home", Icons.Filled.Home),
    BottomItem(Routes.LEARN, "Learn", Icons.Filled.Book),
    BottomItem(Routes.PRACTICE, "Practice", Icons.Filled.Quiz),
    BottomItem(Routes.MORE, "More", Icons.Filled.Menu)
)

@Composable
fun AppNav(vm: MainViewModel, settings: UserSettings?) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBottomBar = route in bottomItems.map { it.route }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val query by vm.query.collectAsState()

    fun toast(message: String) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(message)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        // Each screen handles its own status bar padding; the bottom bar handles the nav bar.
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomItems.forEach { item ->
                        NavigationBarItem(
                            selected = route == item.route,
                            onClick = { nav.navigateToTab(item.route) },
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Routes.SPLASH,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            composable(Routes.SPLASH) {
                SplashScreen(ready = settings != null) {
                    val target = if (settings?.onboardingDone == true) Routes.HOME else Routes.WELCOME
                    nav.navigate(target) { popUpTo(Routes.SPLASH) { inclusive = true } }
                }
            }
            composable(Routes.WELCOME) {
                WelcomeScreen(onContinue = { nav.navigate(Routes.ONBOARDING) })
            }
            composable(Routes.ONBOARDING) {
                OnboardingScreen(onFinished = { nav.navigate(Routes.NAME) })
            }
            composable(Routes.NAME) {
                NameScreen(onContinue = { name ->
                    vm.completeOnboarding(name)
                    nav.navigate(Routes.HOME) { popUpTo(Routes.WELCOME) { inclusive = true } }
                })
            }

            composable(Routes.HOME) {
                if (settings != null) {
                    HomeScreen(
                        settings = settings,
                        query = query,
                        onQueryChange = vm::setQuery,
                        onSearch = { nav.navigateToTab(Routes.LEARN) },
                        onOpenTopic = { id -> nav.openTopic(vm, id) },
                        onOpenLearn = { nav.navigateToTab(Routes.LEARN) },
                        onOpenPractice = { nav.navigateToTab(Routes.PRACTICE) },
                        onOpenProfile = { nav.navigate(Routes.PROFILE) },
                        onOpenSettings = { nav.navigate(Routes.SETTINGS) },
                        onComingSoon = ::toast,
                        showGuide = !settings.guideSeen,
                        onGuideDone = vm::markGuideSeen
                    )
                }
            }
            composable(Routes.LEARN) {
                LearnScreen(
                    query = query,
                    onQueryChange = vm::setQuery,
                    onOpenTopic = { id -> nav.openTopic(vm, id) }
                )
            }
            composable(Routes.PRACTICE) {
                PracticeScreen(onComingSoon = ::toast)
            }
            composable(Routes.MORE) {
                if (settings != null) {
                    MoreScreen(
                        settings = settings,
                        onOpenProfile = { nav.navigate(Routes.PROFILE) },
                        onOpenSettings = { nav.navigate(Routes.SETTINGS) }
                    )
                }
            }

            composable(Routes.PROFILE) {
                if (settings != null) {
                    ProfileScreen(
                        settings = settings,
                        onSaveName = vm::setUserName,
                        onBack = { nav.popBackStack() }
                    )
                }
            }
            composable(Routes.SETTINGS) {
                if (settings != null) {
                    SettingsScreen(
                        settings = settings,
                        onThemeMode = vm::setThemeMode,
                        onPalette = vm::setPalette,
                        onFontScale = vm::setFontScale,
                        onAccessibility = vm::setAccessibilityMode,
                        onReduceMotion = vm::setReduceMotion,
                        onDailyGoal = vm::setDailyGoal,
                        onBack = { nav.popBackStack() }
                    )
                }
            }
            composable("${Routes.TOPIC}/{id}") { entry ->
                val id = entry.arguments?.getString("id").orEmpty()
                TopicScreen(topic = Topics.byId(id), onBack = { nav.popBackStack() })
            }
        }
    }
}

private fun NavHostController.navigateToTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

private fun NavHostController.openTopic(vm: MainViewModel, id: String) {
    vm.recordTopicViewed(id)
    navigate("${Routes.TOPIC}/$id")
}
