package com.completeenglishgrammar.app.ui.theme

import androidx.compose.ui.graphics.Color
import com.completeenglishgrammar.app.data.ThemePalette

/** Fixed brand colours used on the splash, welcome and launcher screens. */
val BrandDeep = Color(0xFF283593)
val BrandIndigo = Color(0xFF3F51B5)
val BrandLight = Color(0xFF5C6BC0)
val BrandAccent = Color(0xFFFFC107)

data class PaletteColors(
    val primary: Color,
    val primaryDark: Color,
    val containerLight: Color,
    val containerDark: Color,
    val secondary: Color
)

fun ThemePalette.colors(): PaletteColors = when (this) {
    ThemePalette.INDIGO -> PaletteColors(
        primary = Color(0xFF3F51B5),
        primaryDark = Color(0xFF9FA8DA),
        containerLight = Color(0xFFE8EAF6),
        containerDark = Color(0xFF283593),
        secondary = Color(0xFFFFB300)
    )
    ThemePalette.EMERALD -> PaletteColors(
        primary = Color(0xFF00796B),
        primaryDark = Color(0xFF80CBC4),
        containerLight = Color(0xFFE0F2F1),
        containerDark = Color(0xFF004D40),
        secondary = Color(0xFFFF7043)
    )
    ThemePalette.SUNSET -> PaletteColors(
        primary = Color(0xFFE64A19),
        primaryDark = Color(0xFFFFAB91),
        containerLight = Color(0xFFFBE9E7),
        containerDark = Color(0xFFBF360C),
        secondary = Color(0xFF5E35B1)
    )
    ThemePalette.ROSE -> PaletteColors(
        primary = Color(0xFFC2185B),
        primaryDark = Color(0xFFF48FB1),
        containerLight = Color(0xFFFCE4EC),
        containerDark = Color(0xFF880E4F),
        secondary = Color(0xFF00ACC1)
    )
    ThemePalette.OCEAN -> PaletteColors(
        primary = Color(0xFF1565C0),
        primaryDark = Color(0xFF90CAF9),
        containerLight = Color(0xFFE3F2FD),
        containerDark = Color(0xFF0D47A1),
        secondary = Color(0xFF43A047)
    )
}
