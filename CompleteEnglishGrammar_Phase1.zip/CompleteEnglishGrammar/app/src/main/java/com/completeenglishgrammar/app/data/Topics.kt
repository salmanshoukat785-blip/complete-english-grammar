package com.completeenglishgrammar.app.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Spellcheck
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.ui.graphics.vector.ImageVector

data class Topic(
    val id: String,
    val title: String,
    val subtitle: String,
    val summary: String,
    val icon: ImageVector
)

object Topics {

    val all: List<Topic> = listOf(
        Topic(
            id = "tenses",
            title = "Tenses",
            subtitle = "Present, past and future",
            summary = "Every tense combines a time (present, past, future) with a type " +
                "(indefinite, continuous, perfect, perfect continuous), which gives 12 tenses.",
            icon = Icons.Filled.Schedule
        ),
        Topic(
            id = "parts_of_speech",
            title = "Parts of Speech",
            subtitle = "The 8 building blocks of English",
            summary = "The eight parts of speech are noun, pronoun, verb, adverb, adjective, " +
                "preposition, conjunction and interjection.",
            icon = Icons.Filled.Category
        ),
        Topic(
            id = "noun",
            title = "Noun",
            subtitle = "Types of nouns with examples",
            summary = "A noun names a person, place or thing. The main types are common, proper, " +
                "countable, uncountable, collective, concrete, abstract and compound nouns.",
            icon = Icons.Filled.Tag
        ),
        Topic(
            id = "helping_verbs",
            title = "Helping Verbs",
            subtitle = "Primary, modal and semi-modal",
            summary = "Primary helping verbs are be, do and have. Modal verbs (can, may, will, " +
                "shall, must and others) are followed by the first form of the verb.",
            icon = Icons.Filled.Build
        ),
        Topic(
            id = "conjunctions",
            title = "Conjunctions",
            subtitle = "Joining words and sentences",
            summary = "Conjunctions join words, phrases or sentences. They can be coordinating " +
                "(for, and, nor, but, or, yet, so), subordinating (because, although, unless) " +
                "or correlative (both ... and).",
            icon = Icons.Filled.Link
        ),
        Topic(
            id = "active_passive",
            title = "Active & Passive Voice",
            subtitle = "Changing the voice of a sentence",
            summary = "In the passive voice the object becomes the subject, and the verb takes " +
                "a form of \"be\" followed by the third form of the main verb.",
            icon = Icons.Filled.SwapHoriz
        ),
        Topic(
            id = "direct_indirect",
            title = "Direct & Indirect Speech",
            subtitle = "Reporting what someone said",
            summary = "To report speech, add a reporting verb (said, told), shift the tense back " +
                "by one step and change the pronouns to fit the new speaker.",
            icon = Icons.Filled.RecordVoiceOver
        ),
        Topic(
            id = "sentence_correction",
            title = "Sentence Correction",
            subtitle = "Spot and fix common mistakes",
            summary = "Learn the rules behind common mistakes in tenses, articles, prepositions, " +
                "agreement and word choice, so you can fix a sentence and explain why.",
            icon = Icons.Filled.Spellcheck
        ),
        Topic(
            id = "comprehension",
            title = "Comprehension",
            subtitle = "Understand and answer passages",
            summary = "Read the passage two or three times, find the main idea, and answer in " +
                "your own words without bringing in outside knowledge.",
            icon = Icons.Filled.Description
        ),
        Topic(
            id = "precis_writing",
            title = "Precis Writing",
            subtitle = "Summarise clearly and briefly",
            summary = "A precis is a summary of about one third of the original. It should be " +
                "clear, correct, coherent and complete, in indirect speech and your own words.",
            icon = Icons.Filled.Edit
        ),
        Topic(
            id = "articles",
            title = "Articles",
            subtitle = "A, an and the",
            summary = "Articles (a, an, the) introduce nouns. Full explanation and examples " +
                "will be added in the next update.",
            icon = Icons.Filled.TextFields
        ),
        Topic(
            id = "prepositions",
            title = "Prepositions",
            subtitle = "In, on, under, above and more",
            summary = "Prepositions show the relationship between words, such as place and time. " +
                "Full explanation and examples will be added in the next update.",
            icon = Icons.Filled.Explore
        )
    )

    fun byId(id: String): Topic? = all.firstOrNull { it.id == id }

    fun search(query: String): List<Topic> {
        val q = query.trim()
        if (q.isEmpty()) return all
        return all.filter {
            it.title.contains(q, ignoreCase = true) ||
                it.subtitle.contains(q, ignoreCase = true) ||
                it.summary.contains(q, ignoreCase = true)
        }
    }
}
