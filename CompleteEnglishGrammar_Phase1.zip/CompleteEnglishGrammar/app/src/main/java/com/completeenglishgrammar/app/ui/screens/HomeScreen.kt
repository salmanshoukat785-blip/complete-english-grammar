package com.completeenglishgrammar.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.completeenglishgrammar.app.data.DailyContent
import com.completeenglishgrammar.app.data.DailyFact
import com.completeenglishgrammar.app.data.DailyQuestion
import com.completeenglishgrammar.app.data.Topic
import com.completeenglishgrammar.app.data.Topics
import com.completeenglishgrammar.app.data.UserSettings
import com.completeenglishgrammar.app.ui.components.Avatar
import com.completeenglishgrammar.app.ui.components.InfoCard
import com.completeenglishgrammar.app.ui.components.LogoMark
import com.completeenglishgrammar.app.ui.components.SectionHeader
import java.time.LocalTime

private data class QuickItem(
    val title: String,
    val icon: ImageVector,
    val onClick: () -> Unit
)

private fun greeting(): String {
    val hour = LocalTime.now().hour
    return when {
        hour < 12 -> "Good morning"
        hour < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

@Composable
fun HomeScreen(
    settings: UserSettings,
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    onOpenTopic: (String) -> Unit,
    onOpenLearn: () -> Unit,
    onOpenPractice: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenSettings: () -> Unit,
    onComingSoon: (String) -> Unit,
    showGuide: Boolean,
    onGuideDone: () -> Unit
) {
    val question = remember { DailyContent.questionOfTheDay() }
    val fact = remember { DailyContent.factOfTheDay() }
    val lastTopic = settings.lastTopicId?.let { Topics.byId(it) }
    val recent = settings.recentTopics.mapNotNull { Topics.byId(it) }
    val firstName = settings.userName.trim().substringBefore(" ").ifEmpty { "Learner" }

    val quickItems = listOf(
        QuickItem("Lessons", Icons.Filled.Book, onOpenLearn),
        QuickItem("Quiz", Icons.Filled.Quiz, onOpenPractice),
        QuickItem("Flashcards", Icons.Filled.Layers) { onComingSoon("Flashcards are coming soon") },
        QuickItem("Notes", Icons.Filled.Edit) { onComingSoon("Notes are coming soon") },
        QuickItem("Question bank", Icons.Filled.Help) { onComingSoon("The question bank is coming soon") },
        QuickItem("AI tutor", Icons.Filled.AutoAwesome) { onComingSoon("The AI tutor is coming soon") }
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LogoMark(size = 40.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Complete English Grammar",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Avatar(
                        name = settings.userName,
                        size = 40.dp,
                        modifier = Modifier.clickable { onOpenProfile() }
                    )
                }
                Spacer(Modifier.height(18.dp))
                Text(
                    text = greeting(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Welcome back, $firstName",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                placeholder = { Text("Search grammar topics") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { onQueryChange("") }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() })
            )
        }

        item {
            Card(
                onClick = { onOpenTopic(lastTopic?.id ?: Topics.all.first().id) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Continue learning",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                        Text(
                            text = lastTopic?.title ?: "Start your first lesson",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = lastTopic?.subtitle ?: "Begin with ${Topics.all.first().title}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = "Open lesson",
                        modifier = Modifier.size(36.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        item {
            Column {
                SectionHeader("Quick access")
                Spacer(Modifier.height(4.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(quickItems) { item -> QuickCard(item) }
                }
            }
        }

        item { DailyQuestionCard(question) }
        item { DailyKnowledgeCard(fact) }

        item {
            InfoCard(icon = Icons.Filled.Flag, title = "Learning goal") {
                Text(
                    text = "Today: 0 of ${settings.dailyGoalQuestions} questions",
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { 0f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape)
                )
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = onOpenSettings) { Text("Change daily goal") }
            }
        }

        item {
            Column {
                SectionHeader("Recently viewed")
                Spacer(Modifier.height(4.dp))
                if (recent.isEmpty()) {
                    Text(
                        text = "Topics you open will appear here.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 20.dp)
                    )
                } else {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column {
                            recent.forEach { topic -> RecentRow(topic) { onOpenTopic(topic.id) } }
                        }
                    }
                }
            }
        }
    }

    if (showGuide) FirstTimeGuide(onDone = onGuideDone)
}

@Composable
private fun QuickCard(item: QuickItem) {
    Card(
        onClick = item.onClick,
        modifier = Modifier.width(108.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = item.title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun DailyQuestionCard(q: DailyQuestion) {
    var revealed by remember { mutableStateOf(false) }
    InfoCard(icon = Icons.Filled.QuestionAnswer, title = "Daily question") {
        Text(
            text = "Correct this sentence:",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = q.wrong,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.error
        )
        AnimatedVisibility(visible = revealed) {
            Column {
                Spacer(Modifier.height(10.dp))
                Text(
                    text = q.correct,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(6.dp))
                Text(text = q.rule, style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(12.dp))
        FilledTonalButton(onClick = { revealed = !revealed }) {
            Text(if (revealed) "Hide answer" else "Show answer")
        }
    }
}

@Composable
private fun DailyKnowledgeCard(fact: DailyFact) {
    InfoCard(icon = Icons.Filled.Lightbulb, title = "Daily knowledge") {
        Text(
            text = fact.title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(4.dp))
        Text(text = fact.text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun RecentRow(topic: Topic, onClick: () -> Unit) {
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        leadingContent = {
            Icon(topic.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        },
        headlineContent = { Text(topic.title, fontWeight = FontWeight.SemiBold) },
        supportingContent = { Text(topic.subtitle) },
        trailingContent = {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
        }
    )
}

@Composable
private fun FirstTimeGuide(onDone: () -> Unit) {
    val steps = remember {
        listOf(
            Triple(Icons.Filled.Home, "Home", "Your dashboard: continue lessons, try the daily question and check your goal."),
            Triple(Icons.Filled.Book, "Learn", "Browse every grammar topic and search for what you need."),
            Triple(Icons.Filled.Quiz, "Practice", "Quizzes and exams will appear here soon."),
            Triple(Icons.Filled.Settings, "More", "Open your profile and settings to change the theme, colours and text size.")
        )
    }
    var step by remember { mutableIntStateOf(0) }
    val current = steps[step]
    val isLast = step == steps.lastIndex

    AlertDialog(
        onDismissRequest = {},
        icon = { Icon(current.first, contentDescription = null) },
        title = { Text("${current.second}  (${step + 1}/${steps.size})") },
        text = { Text(current.third) },
        confirmButton = {
            TextButton(onClick = { if (isLast) onDone() else step += 1 }) {
                Text(if (isLast) "Got it" else "Next")
            }
        },
        dismissButton = {
            TextButton(onClick = onDone) { Text("Skip") }
        }
    )
}
