package com.completeenglishgrammar.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class ThemePalette(val label: String) {
    INDIGO("Indigo"),
    EMERALD("Emerald"),
    SUNSET("Sunset"),
    ROSE("Rose"),
    OCEAN("Ocean")
}

data class UserSettings(
    val onboardingDone: Boolean = false,
    val guideSeen: Boolean = false,
    val userName: String = "",
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val palette: ThemePalette = ThemePalette.INDIGO,
    val fontScale: Float = 1.0f,
    val accessibilityMode: Boolean = false,
    val reduceMotion: Boolean = false,
    val dailyGoalQuestions: Int = 10,
    val lastTopicId: String? = null,
    val recentTopics: List<String> = emptyList()
)

private inline fun <reified T : Enum<T>> parseEnum(value: String?, default: T): T =
    if (value == null) default else runCatching { enumValueOf<T>(value) }.getOrDefault(default)

class UserPrefsRepository(private val context: Context) {

    private object Keys {
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val GUIDE_SEEN = booleanPreferencesKey("guide_seen")
        val USER_NAME = stringPreferencesKey("user_name")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val PALETTE = stringPreferencesKey("palette")
        val FONT_SCALE = floatPreferencesKey("font_scale")
        val ACCESSIBILITY = booleanPreferencesKey("accessibility_mode")
        val REDUCE_MOTION = booleanPreferencesKey("reduce_motion")
        val DAILY_GOAL = intPreferencesKey("daily_goal_questions")
        val LAST_TOPIC = stringPreferencesKey("last_topic_id")
        val RECENT_TOPICS = stringPreferencesKey("recent_topics")
    }

    val settings: Flow<UserSettings> = context.settingsDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            UserSettings(
                onboardingDone = p[Keys.ONBOARDING_DONE] ?: false,
                guideSeen = p[Keys.GUIDE_SEEN] ?: false,
                userName = p[Keys.USER_NAME] ?: "",
                themeMode = parseEnum(p[Keys.THEME_MODE], ThemeMode.SYSTEM),
                palette = parseEnum(p[Keys.PALETTE], ThemePalette.INDIGO),
                fontScale = p[Keys.FONT_SCALE] ?: 1.0f,
                accessibilityMode = p[Keys.ACCESSIBILITY] ?: false,
                reduceMotion = p[Keys.REDUCE_MOTION] ?: false,
                dailyGoalQuestions = p[Keys.DAILY_GOAL] ?: 10,
                lastTopicId = p[Keys.LAST_TOPIC],
                recentTopics = p[Keys.RECENT_TOPICS]
                    ?.split(",")
                    ?.filter { it.isNotBlank() }
                    ?: emptyList()
            )
        }

    suspend fun completeOnboarding(name: String) {
        context.settingsDataStore.edit {
            it[Keys.USER_NAME] = name
            it[Keys.ONBOARDING_DONE] = true
        }
    }

    suspend fun setUserName(name: String) {
        context.settingsDataStore.edit { it[Keys.USER_NAME] = name }
    }

    suspend fun setGuideSeen() {
        context.settingsDataStore.edit { it[Keys.GUIDE_SEEN] = true }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.settingsDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setPalette(palette: ThemePalette) {
        context.settingsDataStore.edit { it[Keys.PALETTE] = palette.name }
    }

    suspend fun setFontScale(scale: Float) {
        context.settingsDataStore.edit { it[Keys.FONT_SCALE] = scale }
    }

    suspend fun setAccessibilityMode(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.ACCESSIBILITY] = enabled }
    }

    suspend fun setReduceMotion(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.REDUCE_MOTION] = enabled }
    }

    suspend fun setDailyGoal(questions: Int) {
        context.settingsDataStore.edit { it[Keys.DAILY_GOAL] = questions }
    }

    suspend fun recordTopicViewed(topicId: String) {
        context.settingsDataStore.edit { prefs ->
            val current = prefs[Keys.RECENT_TOPICS]
                ?.split(",")
                ?.filter { it.isNotBlank() }
                ?: emptyList()
            val updated = (listOf(topicId) + current.filter { it != topicId }).take(5)
            prefs[Keys.RECENT_TOPICS] = updated.joinToString(",")
            prefs[Keys.LAST_TOPIC] = topicId
        }
    }
}
