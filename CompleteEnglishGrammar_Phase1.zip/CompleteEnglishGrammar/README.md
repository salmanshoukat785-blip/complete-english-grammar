# Complete English Grammar (Android, Kotlin)

Native Android app built with Kotlin, Jetpack Compose and Material 3.

## Phase 1 (this version)

- Animated splash, welcome screen, 3-page onboarding (Skip / Next / Get started)
- Name screen and profile (view and edit)
- Home dashboard: greeting, search, continue learning, quick access cards,
  daily question, daily knowledge, learning goal, recently viewed, first-time guide
- Learn tab with topic list and search, and a topic summary screen
- Bottom navigation: Home, Learn, Practice, More
- Settings: light / dark / system, 5 colour themes, text size, high-contrast
  accessibility mode, reduce animations, daily goal
- Settings are saved with DataStore

Practice, flashcards, notes, question bank and AI tutor show "coming soon" for now.

## Roadmap

1. Phase 1: foundation (done)
2. Phase 2: full grammar lessons, quizzes and question bank
3. Phase 3: flashcards, notes, bookmarks, progress, PDF export
4. Phase 4: Gemini AI tutor, Firebase login / backup / sync, support screens

## Build the APK

**Android Studio:** open this folder, wait for the Gradle sync, then
Build > Build Bundle(s) / APK(s) > Build APK(s).

**Command line (needs JDK 17 and the Android SDK):**

```
./gradlew assembleDebug
```

The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

**GitHub:** push this folder to a repository. The workflow in
`.github/workflows/build-apk.yml` builds the APK on every push to `main`
(Actions tab > latest run > Artifacts).

## Requirements

- Android 8.0 (API 26) or newer
- JDK 17
