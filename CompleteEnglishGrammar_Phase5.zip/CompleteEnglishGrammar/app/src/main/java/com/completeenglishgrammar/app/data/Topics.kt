package com.completeenglishgrammar.app.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Spellcheck
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.ui.graphics.vector.ImageVector

data class Topic(
    val id: String,
    val title: String,
    val subtitle: String,
    val summary: String,
    val icon: ImageVector
)

object Topics {

    val all: List<Topic> = listOf(
        Topic(
            id = "parts_of_speech",
            title = "Parts of Speech",
            subtitle = "The 8 building blocks of English",
            summary = "The eight parts of speech are noun, pronoun, verb, adverb, adjective, " +
                "preposition, conjunction and interjection.",
            icon = Icons.Filled.Category
        ),
        Topic(
            id = "noun",
            title = "Noun",
            subtitle = "Types of nouns with examples",
            summary = "A noun names a person, place or thing. The main types are common, proper, " +
                "countable, uncountable, collective, concrete, abstract and compound nouns.",
            icon = Icons.Filled.Tag
        ),
        Topic(
            id = "pronouns",
            title = "Pronouns",
            subtitle = "I, me, my, mine, who and whom",
            summary = "A pronoun takes the place of a noun. Learn personal, possessive, reflexive, relative and demonstrative pronouns, and when to use who or whom.",
            icon = Icons.Filled.Person
        ),
        Topic(
            id = "adjectives",
            title = "Adjectives",
            subtitle = "Describing words and comparison",
            summary = "Adjectives describe nouns. Learn their order, the degrees of comparison (good, better, best) and words like little, few, much and many.",
            icon = Icons.Filled.Palette
        ),
        Topic(
            id = "adverbs",
            title = "Adverbs",
            subtitle = "How, when, where and how often",
            summary = "Adverbs describe verbs, adjectives and other adverbs. Learn their types, their position in a sentence and the difference between forms like hard and hardly.",
            icon = Icons.Filled.Speed
        ),
        Topic(
            id = "verbs",
            title = "Verbs",
            subtitle = "Types and forms of the verb",
            summary = "Learn main and helping verbs, transitive and intransitive verbs, regular and irregular verbs, and the three forms V1, V2 and V3.",
            icon = Icons.Filled.Bolt
        ),
        Topic(
            id = "helping_verbs",
            title = "Helping Verbs",
            subtitle = "Primary, modal and semi-modal",
            summary = "Primary helping verbs are be, do and have. Modal verbs (can, may, will, " +
                "shall, must and others) are followed by the first form of the verb.",
            icon = Icons.Filled.Build
        ),
        Topic(
            id = "tenses",
            title = "Tenses",
            subtitle = "Present, past and future",
            summary = "Every tense combines a time (present, past, future) with a type " +
                "(indefinite, continuous, perfect, perfect continuous), which gives 12 tenses.",
            icon = Icons.Filled.Schedule
        ),
        Topic(
            id = "subject_verb_agreement",
            title = "Subject-Verb Agreement",
            subtitle = "Making the verb match the subject",
            summary = "A singular subject takes a singular verb and a plural subject takes a plural verb. Learn the tricky cases: each, either, neither, collective nouns and along with.",
            icon = Icons.Filled.Balance
        ),
        Topic(
            id = "nonfinite",
            title = "Gerund, Infinitive & Participle",
            subtitle = "Verb forms that act like other words",
            summary = "Gerunds (-ing) act as nouns, infinitives (to + V1) name actions, and participles act as adjectives. Learn which verbs take which form.",
            icon = Icons.Filled.Autorenew
        ),
        Topic(
            id = "conditionals",
            title = "Conditionals",
            subtitle = "If sentences: zero, first, second, third",
            summary = "Conditional sentences state a condition and its result. Learn the zero, first, second and third conditionals and the use of unless and wish.",
            icon = Icons.Filled.CallSplit
        ),
        Topic(
            id = "articles",
            title = "Articles",
            subtitle = "A, an and the",
            summary = "Articles (a, an, the) introduce nouns. Use \"an\" before a vowel sound, " +
                "\"a\" before a consonant sound, and \"the\" for something specific or unique.",
            icon = Icons.Filled.TextFields
        ),
        Topic(
            id = "prepositions",
            title = "Prepositions",
            subtitle = "In, on, under, above and more",
            summary = "Prepositions show the relationship between words, such as place and time. " +
                "Learn at / on / in, between / among and common word-preposition pairs.",
            icon = Icons.Filled.Explore
        ),
        Topic(
            id = "conjunctions",
            title = "Conjunctions",
            subtitle = "Joining words and sentences",
            summary = "Conjunctions join words, phrases or sentences. They can be coordinating " +
                "(for, and, nor, but, or, yet, so), subordinating (because, although, unless) " +
                "or correlative (both ... and).",
            icon = Icons.Filled.Link
        ),
        Topic(
            id = "phrases_clauses",
            title = "Phrases & Clauses",
            subtitle = "Groups of words in a sentence",
            summary = "A phrase has no subject and verb of its own; a clause does. Learn noun, adjective and adverb clauses, and main and subordinate clauses.",
            icon = Icons.Filled.ViewModule
        ),
        Topic(
            id = "sentence_types",
            title = "Types of Sentences",
            subtitle = "Simple, compound and complex",
            summary = "Sentences can be simple, compound, complex or compound-complex, and also statements, questions, commands or exclamations.",
            icon = Icons.Filled.AccountTree
        ),
        Topic(
            id = "active_passive",
            title = "Active & Passive Voice",
            subtitle = "Changing the voice of a sentence",
            summary = "In the passive voice the object becomes the subject, and the verb takes " +
                "a form of \"be\" followed by the third form of the main verb.",
            icon = Icons.Filled.SwapHoriz
        ),
        Topic(
            id = "direct_indirect",
            title = "Direct & Indirect Speech",
            subtitle = "Reporting what someone said",
            summary = "To report speech, add a reporting verb (said, told), shift the tense back " +
                "by one step and change the pronouns to fit the new speaker.",
            icon = Icons.Filled.RecordVoiceOver
        ),
        Topic(
            id = "question_tags",
            title = "Question Tags",
            subtitle = "Isn't it? Don't you?",
            summary = "A question tag is a short question added to a statement. A positive statement takes a negative tag and the other way round.",
            icon = Icons.Filled.HelpOutline
        ),
        Topic(
            id = "punctuation",
            title = "Punctuation & Capitals",
            subtitle = "Commas, apostrophes, quotes and more",
            summary = "Learn when to use the full stop, comma, semicolon, colon, apostrophe, quotation marks and capital letters.",
            icon = Icons.Filled.FormatQuote
        ),
        Topic(
            id = "sentence_correction",
            title = "Sentence Correction",
            subtitle = "Spot and fix common mistakes",
            summary = "Learn the rules behind common mistakes in tenses, articles, prepositions, " +
                "agreement and word choice, so you can fix a sentence and explain why.",
            icon = Icons.Filled.Spellcheck
        ),
        Topic(
            id = "comprehension",
            title = "Comprehension",
            subtitle = "Understand and answer passages",
            summary = "Read the passage two or three times, find the main idea, and answer in " +
                "your own words without bringing in outside knowledge.",
            icon = Icons.Filled.Description
        ),
        Topic(
            id = "precis_writing",
            title = "Precis Writing",
            subtitle = "Summarise clearly and briefly",
            summary = "A precis is a summary of about one third of the original. It should be " +
                "clear, correct, coherent and complete, in indirect speech and your own words.",
            icon = Icons.Filled.Edit
        ),
        Topic(
            id = "writing",
            title = "Letters, Applications & Essays",
            subtitle = "Formal writing made simple",
            summary = "Learn the layout of letters and applications, how to plan an essay, and how to write a clear introduction, body and conclusion.",
            icon = Icons.Filled.Mail
        ),
        Topic(
            id = "vocabulary",
            title = "Vocabulary",
            subtitle = "Synonyms, antonyms and one-word substitutes",
            summary = "Build your word power with synonyms, antonyms, one-word substitutes, homophones and commonly confused words.",
            icon = Icons.Filled.MenuBook
        ),
        Topic(
            id = "idioms",
            title = "Idioms & Phrasal Verbs",
            subtitle = "Expressions with special meanings",
            summary = "Idioms and phrasal verbs have meanings that differ from their separate words. Learn common ones with examples and use them correctly.",
            icon = Icons.Filled.Lightbulb
        )
    )

    fun byId(id: String): Topic? = all.firstOrNull { it.id == id }

    fun search(query: String): List<Topic> {
        val q = query.trim()
        if (q.isEmpty()) return all
        return all.filter {
            it.title.contains(q, ignoreCase = true) ||
                it.subtitle.contains(q, ignoreCase = true) ||
                it.summary.contains(q, ignoreCase = true)
        }
    }
}
