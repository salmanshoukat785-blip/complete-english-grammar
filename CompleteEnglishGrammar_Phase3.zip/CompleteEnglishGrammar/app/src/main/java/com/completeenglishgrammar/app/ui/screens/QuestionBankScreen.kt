package com.completeenglishgrammar.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.completeenglishgrammar.app.data.Difficulty
import com.completeenglishgrammar.app.data.QStat
import com.completeenglishgrammar.app.data.Question
import com.completeenglishgrammar.app.data.QuestionType
import com.completeenglishgrammar.app.data.Topics
import com.completeenglishgrammar.app.ui.components.SimpleTopBar
import com.completeenglishgrammar.app.ui.theme.correctColor
import com.completeenglishgrammar.app.ui.theme.wrongColor

private enum class StatusFilter(val label: String) {
    ALL("All"),
    IMPORTANT("Important"),
    WRONG("Wrong last time"),
    UNATTEMPTED("Unattempted")
}

@Composable
fun QuestionBankScreen(
    questions: List<Question>,
    stats: Map<String, QStat>,
    favourites: Set<String>,
    onToggleFavourite: (String) -> Unit,
    onBack: () -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var topicId by rememberSaveable { mutableStateOf<String?>(null) }
    var difficulty by rememberSaveable { mutableStateOf<Difficulty?>(null) }
    var type by rememberSaveable { mutableStateOf<QuestionType?>(null) }
    var status by rememberSaveable { mutableStateOf(StatusFilter.ALL) }
    val expanded = remember { mutableStateMapOf<String, Boolean>() }

    val filtered = remember(questions, stats, query, topicId, difficulty, type, status) {
        val q = query.trim()
        questions.filter { item ->
            (topicId == null || item.topicId == topicId) &&
                (difficulty == null || item.difficulty == difficulty) &&
                (type == null || item.type == type) &&
                when (status) {
                    StatusFilter.ALL -> true
                    StatusFilter.IMPORTANT -> item.important
                    StatusFilter.WRONG -> stats[item.id]?.let { it.attempts > 0 && !it.lastCorrect } == true
                    StatusFilter.UNATTEMPTED -> (stats[item.id]?.attempts ?: 0) == 0
                } &&
                (q.isEmpty() ||
                    item.text.contains(q, ignoreCase = true) ||
                    item.explanation.contains(q, ignoreCase = true) ||
                    item.options.any { it.contains(q, ignoreCase = true) })
        }
    }

    Scaffold(
        topBar = { SimpleTopBar(title = "Question bank", onBack = onBack) },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                placeholder = { Text("Search questions") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp)
            )
            Spacer(Modifier.height(8.dp))

            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(selected = topicId == null, onClick = { topicId = null }, label = { Text("All topics") })
                }
                items(Topics.all) { t ->
                    FilterChip(selected = topicId == t.id, onClick = { topicId = t.id }, label = { Text(t.title) })
                }
            }
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(selected = difficulty == null, onClick = { difficulty = null }, label = { Text("Any level") })
                }
                items(Difficulty.entries.toList()) { d ->
                    FilterChip(selected = difficulty == d, onClick = { difficulty = d }, label = { Text(d.label) })
                }
                items(StatusFilter.entries.toList()) { s ->
                    FilterChip(selected = status == s, onClick = { status = s }, label = { Text(s.label) })
                }
            }
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(selected = type == null, onClick = { type = null }, label = { Text("Any type") })
                }
                items(QuestionType.entries.toList()) { t ->
                    FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t.label) })
                }
            }

            Text(
                text = "${filtered.size} of ${questions.size} questions",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )

            if (filtered.isEmpty()) {
                Text(
                    text = "No questions match. Try removing a filter.",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 24.dp)
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filtered, key = { it.id }) { q ->
                        QuestionCard(
                            question = q,
                            stat = stats[q.id],
                            open = expanded[q.id] == true,
                            favourite = q.id in favourites,
                            onToggle = { expanded[q.id] = !(expanded[q.id] ?: false) },
                            onFavourite = { onToggleFavourite(q.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
internal fun QuestionCard(
    question: Question,
    stat: QStat?,
    open: Boolean,
    favourite: Boolean,
    onToggle: () -> Unit,
    onFavourite: () -> Unit
) {
    val topicTitle = Topics.byId(question.topicId)?.title ?: question.topicId
    Card(
        onClick = onToggle,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "$topicTitle - ${question.difficulty.label} - ${question.type.label}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                if (question.important) {
                    Text(
                        "Important",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onClick = onFavourite) {
                    Icon(
                        imageVector = if (favourite) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = if (favourite) "Remove from favourites" else "Add to favourites",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            Text(
                text = question.text,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold
            )
            if (stat != null) {
                Text(
                    text = if (stat.lastCorrect) "Answered correctly last time" else "Answered wrongly last time",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (stat.lastCorrect) correctColor() else wrongColor()
                )
            }
            if (open) {
                question.options.forEachIndexed { i, text ->
                    OptionRow(
                        letter = ('A' + i).toString(),
                        text = text,
                        state = if (i == question.answerIndex) OptionState.CORRECT else OptionState.NORMAL,
                        enabled = false,
                        onClick = {}
                    )
                }
                if (question.explanation.isNotBlank()) {
                    Text(
                        text = question.explanation,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Text(
                    text = "Tap to see the answer",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
