# Complete English Grammar (Android, Kotlin)

Native Android app built with Kotlin, Jetpack Compose and Material 3.

## Phase 1: foundation (done)

- Animated splash, welcome screen, 3-page onboarding, name screen, profile
- Home dashboard, bottom navigation, search
- Settings: light / dark, 5 colour themes, text size, high-contrast mode,
  reduce animations, daily goal (saved with DataStore)

## Phase 2: lessons, quizzes, question bank (done)

- 12 grammar topics with full lessons, built from the PDF and extended
  (Articles and Prepositions were written new)
- Lesson screen: easy summary / detailed lesson, tables, examples,
  important-point highlights, wrong-to-correct fixes, table of contents,
  related topics, text selection and copy, read aloud (text-to-speech)
- 248 questions: multiple choice, fill in the blank, sentence correction,
  error spotting; easy / medium / hard; explanation for every answer
- Quiz modes: practice, self-test, timed, speed test, exam (negative marking),
  daily challenge, weekly challenge, random mix, wrong answers, unattempted
- Result screen with score, review of every answer, practise-the-mistakes, share
- Question bank: search, filter by topic / level / type, important, wrong, unattempted
- Home goal bar counts the questions answered today

Lessons and questions live in `app/src/main/assets/lessons.json` and
`questions.json`. You can edit or add content there without touching the code.

## Phase 3: study tools (this version)

- Flashcards with spaced repetition (Leitner boxes): sentence fixes, 62 vocabulary
  words (with Urdu), key questions, and your own cards
- Notes (per topic or general), lesson bookmarks, favourite questions (star in the Question bank)
- My progress: day / week / month streaks, points, study time, topic accuracy, badges
- PDF export and printing: lessons, notes, quiz results, progress report
- All data is stored on the phone (DataStore). More menu has the new screens.

## Roadmap

4. Gemini AI tutor, Firebase login / backup / sync, support screens

## Build the APK

**Android Studio:** open this folder, wait for the Gradle sync, then
Build > Build Bundle(s) / APK(s) > Build APK(s).

**Command line (needs JDK 17 and the Android SDK):**

```
./gradlew assembleDebug
```

The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

**GitHub:** the workflow in `.github/workflows/build-apk.yml` builds the APK on
every push to `main` (Releases or Actions > Artifacts).

## Requirements

- Android 8.0 (API 26) or newer
- JDK 17
